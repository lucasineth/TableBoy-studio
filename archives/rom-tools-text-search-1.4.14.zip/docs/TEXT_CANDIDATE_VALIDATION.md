# Validação — Text Candidate Analyzer

## Automatizada

A suíte passou com 293 testes, incluindo 17 novos nesta etapa (16 do analisador
e 1 de integração do worker). São cobertos os cinco codecs, métricas Unicode,
repetição e períodos curtos, textos legítimos curtos classificados Low, controles,
erros explícitos, tokens explicitamente fornecidos por decoder, determinismo,
previews truncados, filtros reversíveis, offsets de batches e cancelamento real.
TypeScript, ESLint, build Electron/Vite, Prettier e `git diff --check` passaram.

## Electron — fluxo ponta a ponta

Foi executado o bundle real no Electron, com Main, preload, IPC, Coordinator e
worker de produção. Um adaptador temporário de `dialog.showOpenDialog` selecionou
apenas dois binários sintéticos locais. Não foi um teste manual do diálogo nativo.
O adaptador e os arquivos temporários foram removidos depois da validação.

- Abertura do binário sintético e execução de String Scanner ASCII.
- Quatro resultados: frase, menu curto, repetição e números.
- High/Low visíveis, detalhes e evidências do candidato selecionado.
- Filtro High: um resultado; Clear filters: quatro originais.
- Hide highly repetitive: três resultados; Clear filters: quatro originais.
- Documento de 64 MiB: Cancel após progresso maior que zero terminou como Cancelled.
- Nova busca e Close ROM durante execução: estado sem documento/resultados.
- Nenhuma exceção do Renderer registrada pelo Chrome DevTools Protocol.

Os controles/filtros foram acionados na interface renderizada via CDP, não por
chamadas diretas ao scanner. A validação manual por usuário do diálogo nativo,
teclado, aparência em outras escalas de tela e demais sistemas continua no checklist.
Nenhuma ROM comercial foi usada.

## Arquivos desta etapa

Criados:

- `src/core/search/TextCandidateAnalyzer.ts`
- `src/renderer/src/features/rom-search/CandidateResults.tsx`
- `test/core/textCandidateAnalyzer.test.mts`
- `docs/text-candidate-analyzer.md`
- `docs/TEXT_CANDIDATE_VALIDATION.md`

Modificados:

- `src/core/search/StringScannerTypes.ts`: metadado opcional de análise.
- `src/main/search/searchWorker.ts`: enriquecimento de batches, cancelamento e boundaries.
- `src/renderer/src/features/rom-search/RomSearchPanel.tsx`: integração do painel.
- `src/renderer/src/features/rom-search/SearchResults.tsx`: classificação e resumo.
- `src/renderer/src/assets/main.css`: filtros e detalhes compactos.
- `test/main/stringScannerIntegration.test.mts`: análise no worker e cancelamento.
- `package.json`, `package-lock.json`,
  `src/renderer/src/components/AppDialog/AppDialog.tsx`: candidata 1.4.12, não publicada.
- `README.md`, `CHANGELOG.md`, `docs/REGRESSION_CHECKLIST.md`: estado real e limitações.

As alterações anteriores do Create Table Assistant e da consolidação foram preservadas.
Não foram alterados os algoritmos de busca, BinaryDocument, Registry, Coordinator,
contratos de requests, handlers IPC ou codecs. Nenhuma dependência foi adicionada,
e nenhum commit, tag ou release foi criado.
