# Validação — Known-Text Discovery v1.4.14

## Arquivos e arquitetura

Criados:

- `src/core/search/KnownTextTypes.ts`: contratos serializáveis e limites.
- `src/core/search/KnownTextSearch.ts`: composição sequencial das engines existentes.
- `src/renderer/src/features/rom-search/KnownTextResults.tsx`: grupos, paginação,
  inspector e entrada para o Create Table Assistant existente.
- `test/core/knownTextSearch.test.mts`
- `test/main/knownTextIntegration.test.mts`
- `test/renderer/knownTextUi.test.mts`
- `docs/known-text-discovery.md` e este relatório.

Modificados:

- `src/main/search/SearchProtocol.ts`, `searchWorker.ts`, `SearchIpcPolicy.ts`:
  novo request/batch `known` nos canais existentes, validação e delegação ao core.
- `src/main/search/SearchErrorSerialization.ts`: detalhes estruturados de erros
  dos encodings (posição, fragmento, motivo e encoding).
- `src/renderer/src/features/rom-search/searchRequest.ts`, `SearchControls.tsx`:
  modalidade, parser por linhas, métodos e reutilização dos controles relativos.
- `romSearchTypes.ts`, `useRomSearch.ts`, `RomSearchPanel.tsx`, `SearchResults.tsx`
  na mesma pasta: origem discriminada, snapshot das queries e apresentação isolada.
- `src/renderer/src/App.tsx`: nome da tabela na busca e foco contextual da query.
- `src/renderer/src/assets/main.css`: textarea, grupos e nota de limites.
- `package.json`, `package-lock.json`, About: candidata 1.4.14, não publicada.
- `README.md`, `CHANGELOG.md`, `docs/REGRESSION_CHECKLIST.md`: documentação.

Não foram modificados BinarySearchEngine, RelativeSearchEngine, TableSearchEngine,
algoritmos dos codecs/encodings, BinaryDocument, Registry ou Coordinator. Não houve
dependência, canal IPC, worker, commit, tag ou release novo.

## Testes e checks

336/336 testes aprovados: 26 novos (19 core, 3 integração IPC/worker e 4 apresentação).
Cobertura inclui ASCII, os quatro codecs existentes, tabela com tokens/chaves
variáveis, relativo 8/16-bit LE/BE, espaços, repetições, wildcards, sequência customizada,
consultas duplicadas agrupadas separadamente, overlaps, limite global, progresso,
cancelamento, contexto não decodificável, previews limitados, conflitos e importação
revisada pelo serviço do Create Table Assistant. Dados aleatórios usam seed fixa.

TypeScript, ESLint, build Electron/Vite, Prettier e `git diff --check` executados.
Os contratos atuais de ownership e cleanup permanecem cobertos pela suíte existente.

## Electron — teste automatizado ponta a ponta

Bundle real com Main/preload/IPC/Coordinator/worker. UI acionada por CDP, usando um
adaptador temporário apenas no diálogo de seleção para restringir os arquivos a
fixtures sintéticas locais. Não foi validação manual do diálogo nativo; essa etapa
e a homologação humana continuam pendentes.

Confirmado:

- Exact Encoding ASCII com `HELLO WORLD` e `LEVEL`: três matches em grupos por query.
- Inspector exato mostrou bytes/contexto e ausência de mappings, sem inventá-los.
- Loaded Table com `ABC`: origem nomeada `example.tbl` no resultado.
- Relative com `ABC`: mappings explicitamente candidatos; Create Table abriu o
  MappingInspector existente com todas as associações inicialmente não aprovadas.
- Cancelar o assistente não alterou a tabela.
- Busca relativa em 64 MiB cancelada após progresso positivo; estado Cancelled.
- Substituição por outro arquivo não apresentou matches antigos; fechamento limpou UI.
- Nenhuma exceção do Renderer registrada nessas verificações.
- Os hashes SHA-256 antes/depois foram iguais:

| Fixture       | SHA-256                                                            |
| ------------- | ------------------------------------------------------------------ |
| synthetic.bin | `4ae3e5cce4abc8d402bd77dc69ff4cb6821d3bc5dac9a9b6f396ba465f5f51f6` |
| large.bin     | `3b6a07d0d404fab4e23b6d34bc6696a6a312dd92821332385e5af7c01c421351` |
| other.bin     | `5adf016bdd071bdd8be9efbe92899db2c4047dab05b54ee79c14411c6e45ea38` |

Scripts, adaptador e binários temporários removidos após teste. Nenhuma ROM comercial
foi utilizada ou incluída. Aplicação, Undo/Redo e Save do assistente continuam no
fluxo existente, com cobertura automatizada; nesta verificação visual foi conferida
a abertura/revisão/cancelamento, sem gravar `.tbl` ou ROM.

## Limitações

Uma estratégia por lote; Auto Strategy e comparação histórica/lado a lado não foram
implementadas. Repetir consultas com outra estratégia substitui o lote anterior.
Limite global/erro/cancelamento pode deixar queries posteriores não executadas;
zero recebido não prova ausência de correspondências. O lote é fail-fast em erros.

Dados comprimidos, criptografados, fragmentados, códigos de controle e encodings
arbitrários podem não ser encontrados. Relativo requer relações modulares compatíveis;
nenhum match comprova diálogo ou charmap. Contexto arbitrário pode falhar no decode.
Somente mappings observados são revisáveis; não há alfabetos completos inferidos.
