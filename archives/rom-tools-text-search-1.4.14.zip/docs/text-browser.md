# Text Browser — v1.4.13 (etapa interna, não publicada)

## Uso

1. Em ROM Tools → Text Search, abrir um binário pelo diálogo nativo.
2. Selecionar String Scanner e configurar o encoding/filtros/range.
3. Search inicia a única sessão existente; não há busca automática.
4. Selecionar Text Browser na navegação principal, inclusive durante a busca.
5. Selecionar candidatos para consultar texto disponível, offset, encoding,
   comprimento em bytes/caracteres, evidências, métricas e possíveis boundaries.

Text Search continua disponível para Table Search, Relative Search, Value Scan e
Create Table Assistant. O browser não mistura esses resultados com String Scanner.

## Estado e origem

`useRomSearch` continua responsável pelos listeners IPC e pela única fonte de
resultados. O adaptador `adaptTextResults` apenas cria metadata de apresentação,
mantendo referências ao resultado, preview, bytes e análise. Identidade:
documentId + runId + offset + encoding. Índices não identificam permanentemente itens.
Scanner, Analyzer, BinaryDocument, Registry, Coordinator, worker e IPC não mudaram.

Table Editor, Browser e Text Search permanecem montados ao alternar ferramentas, preservando
configuração, filtros e seleção locais. O browser reinicia ao mudar documento ou
runId. Close remove o estado e a UI; batches antigos são rejeitados pelo lifecycle
existente. Cancelamento/erro mantêm candidatos parciais já recebidos para inspeção,
mas eventos posteriores à conclusão não são incorporados.

## Filtros, ordenação e navegação

- Filtros da v1.4.12 reutilizados: confiança mínima, mínimo de code points, letras,
  repetição e erros explicitamente reportados.
- Encoding é explícito. Cada sessão atual tem um encoding; não há histórico
  agregado de múltiplas varreduras.
- Pesquisa literal case-insensitive no preview disponível; sem regex, normalização,
  nova busca, leitura de contexto ou tentativa de recuperar o restante de strings.
- Ordenação por offset, comprimento **em bytes** ou confiança existente. Ambas as
  direções são suportadas; empates usam offset crescente, preservando estabilidade.
  Confiança ausente não é fabricada (fica abaixo de Low na ordenação crescente).
- Reset browser filters restaura todos os filtros/ordenação do browser; Clear filters
  do grupo de candidatos restaura apenas os filtros daquele grupo.
- A seleção permanece quando o item ainda pertence ao conjunto filtrado e é removida
  quando deixa de pertencer. Restaurar filtros não ressuscita uma seleção removida.
- Previous/Next text, ArrowUp/ArrowDown e Home/End no foco da lista navegam pelos
  candidatos filtrados; mudanças de seleção posicionam a página correspondente.
- Páginas de 100 linhas. Não há DOM proporcional ao tamanho da ROM; apenas wrappers
  de metadata sobre resultados limitados pelo IPC (até 10.000).

## Inspector e limites

O inspector mostra o preview efetivamente decodificado, nunca uma string fictícia.
`previewTruncated` indica que o texto completo não está disponível. `analysis.scope`
informa se métricas/evidências descrevem só o preview. Confidence é heurística,
não probabilidade estatística nem confirmação de diálogo. Indícios NUL, line-break,
EOF ou range-end não provam terminadores. Ausência de análise é apresentada como tal.
Erros do job são mostrados pelo feedback existente; contagens/evidências de erros
de decodificação são exibidas somente quando fornecidas pelo Analyzer.

O scanner atual é estrito: encerra runs diante de controles/bytes inválidos e não
produz candidatos com essas falhas. Não utiliza `.tbl`; Text Browser também não.
Tokens não são inferidos e não há reconstrução de texto completo, exportação,
tradução, escrita de ROM, Hex Viewer ou inferência de charmap.

Textos comprimidos/proprietários podem não ser detectados; strings curtas ou
repetitivas legítimas podem receber Low. Japonês usa as métricas Unicode existentes,
sem exigência de espaços latinos. Falsos positivos continuam possíveis.

## Melhorias futuras (não implementadas)

- Planejar uma origem explícita para textos decodificados por `.tbl`.
- Recuperação limitada e autorizada de texto completo sob demanda.
- Avaliar virtualização somente se paginação e limites atuais deixarem de atender.
- Histórico de sessões apenas com política explícita de memória/lifecycle.
