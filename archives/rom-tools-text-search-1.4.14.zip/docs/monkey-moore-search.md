# Busca relativa com bases independentes

Em ROM Tools → Text Search → Relative Search, selecionar Text e Unicode values e
ativar **Independent uppercase/lowercase bases**. A mesma opção está disponível em
Known-Text Search → Strategy → Relative Search.

O padrão continua sendo um deslocamento modular comum para todos os caracteres.
A nova opção permite deslocamentos separados para letras ASCII maiúsculas e
minúsculas. Por exemplo, `Abcd` encontra `80 21 22 23`: as diferenças entre `b`, `c`
e `d` continuam sendo +1, mas a base de `A` é independente. Não há conversão de
caixa; cada letra preserva sua identidade e seu mapeamento candidato.

São necessárias pelo menos três letras da mesma caixa. Apenas letras ASCII e
curingas habilitados são aceitos. `?` ignora uma posição e não gera mapeamento.
Uma sequência personalizada define sua própria relação e não combina com essa
opção. Value Scan continua usando apenas as diferenças numéricas fornecidas.

Funciona com 8 bits, 16 bits little-endian/big-endian, offsets pares ou ímpares
(alignment 1), range, limite de resultados e cancelamento existentes. Símbolos
distintos continuam exigindo valores distintos; letras repetidas devem coincidir.
Os resultados continuam candidatos, disponíveis para revisão no Create Table.

Base: `MEMORY.md` e a análise estática preservada do Monkey-Moore, especialmente
`analysis/resource-findings.md` no workspace original. Trata-se de uma adaptação ao
motor existente; não constitui reprodução integral nem prova de equivalência com
o executável. Curingas, sequência customizada, Value Scan e 8/16 bits já existiam.
O algoritmo de varredura e a arquitetura de worker atuais foram preservados.
