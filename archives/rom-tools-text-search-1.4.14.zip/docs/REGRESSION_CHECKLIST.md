# Checklist de regressão — candidata v1.4.11

Este roteiro não representa testes já executados. Marque cada item somente após
verificar no Electron. Use arquivos temporários sintéticos e backup das tabelas;
nenhuma etapa deve escrever no binário.

## Registro da execução

- Commit/estado do worktree:
- Sistema operacional, Node e Electron:
- Data e responsável:
- Modo: desenvolvimento / build / aplicativo empacotado:
- Resultado, falhas e evidências:

## Preparação e fixtures

Execute `npm ci`, `npm run dev` e, em outra execução, `npm run build` seguido de
`npm start`. Verifique About **1.4.11**. Use ferramenta externa para criar binários;
o TableBoy não é editor binário. Compare hashes antes/depois da execução.

Tabela 8-bit UTF-8:

```text
48=H
45=E
4C=L
4F=O
F1=Ã
```

Tabela 16-bit separada:

```text
8140=あ
8141=い
8200=う
F100=[PLAYER]
```

Bytes hexadecimais de `synthetic.bin`:

```text
00 48 45 4C 4C 4F 00 81 82 83 84 85 00
40 81 41 81 42 81 00 81 40 81 41 81 42 00
82 A0 82 A2 00
```

Use também arquivo vazio, strings repetidas para mais de uma página de resultados
e binário grande determinístico para cancelamento. Não use ROMs comerciais.

## Arquivos `.tbl` e proteção de dados

- [ ] New cria tabela vazia 8-bit, `Untitled.tbl`, sem modified.
- [ ] Open posiciona Unicode nas chaves corretas e limpa histórico anterior.
- [ ] Edit marca modified; Save salva UTF-8 e limpa o indicador.
- [ ] Save sem caminho usa Save As; extensão `.tbl` e reabertura preservam valores.
- [ ] Cancelar diálogos de Open/Save As preserva documento e alterações.
- [ ] Antes de New/Open/Exit/X, testar Save, Don't Save e Cancel separadamente.
- [ ] Cancelar Save As na proteção também aborta a operação destrutiva.
- [ ] Drag & Drop respeita proteção contra alterações não salvas.
- [ ] Linhas inválidas/duplicatas exibem linha/conteúdo/motivo, sem ignorá-las.

## Editor e Character Picker

- [ ] 8-bit: linha 4/coluna 1 = `41`; linha F/coluna 1 = `F1`.
- [ ] Inspector mostra hex, decimal, valor e Unicode quando aplicável.
- [ ] Editar tokens não limita o valor a um caractere.
- [ ] 16-bit: páginas `81`/`82`, navegação manual e retorno preservam valores.
- [ ] Save/reopen conserva `8140`, `8200` e `F100` sem truncamento.
- [ ] Arquivo com larguras incompatíveis apresenta erro controlado.
- [ ] Clique direito seleciona célula; abrir categoria não altera valores.
- [ ] Escolher letra/número/PT-BR/Hiragana altera só a célula clicada.
- [ ] Repetir no 16-bit: vizinhas e outras páginas permanecem intactas.
- [ ] Clear, edição e picker participam do Undo/Redo; Ctrl+Z/Ctrl+Y funcionam.
- [ ] Busca de entrada, menus e atalhos existentes continuam funcionando.
- [ ] Não existe preenchimento sequencial no picker.

## Abertura e lifecycle do binário

- [ ] ROM Tools abre diálogo nativo; cancelar preserva o documento atual.
- [ ] Abrir `synthetic.bin` mostra nome e tamanho, sem caminho completo.
- [ ] Arquivo vazio tem estado apropriado e não permite busca inválida.
- [ ] Close limpa resultados/progresso/seleção e permite reabrir.
- [ ] Close durante busca cancela job; eventos antigos não chegam ao documento novo.
- [ ] Fechar janela não deixa jobs/processos pendentes observáveis.
- [ ] Não existem Hex Viewer, “Open in Hex Viewer” ou controles de escrita.

## Table Search

- [ ] Tabela vazia desabilita Search com explicação visível.
- [ ] `HELLO` retorna offset `1`, length `5` e bytes corretos.
- [ ] Caractere ausente mostra erro útil com posição/fragmento quando presentes.
- [ ] Contexto truncado nas bordas não invalida match.
- [ ] Contexto indecodificável conserva resultado e não inventa texto.
- [ ] Fixture adicional 16-bit/token verifica length em bytes, não caracteres.

## Relative Search

- [ ] 8-bit `ABCDE` encontra `81 82 83 84 85` no offset `7`.
- [ ] Mapping não duplica símbolos repetidos; bytes/length correspondem ao match.
- [ ] 16-bit LE `ABC`: offset `13`, bytes `40 81 41 81 42 81`, length `6`.
- [ ] 16-bit BE `ABC`: offset `20`, bytes `81 40 81 41 81 42`, length `6`.
- [ ] Byte order é explícito em 16-bit e não tem opção/efeito em 8-bit.
- [ ] Alignment `2` exclui match LE no offset ímpar; ranges contam bytes.
- [ ] Query vazia/curta tem erro; dois símbolos exigem opção explícita.

## Advanced Relative Search

- [ ] Wildcards: `AB?DE` encontra candidato e não mapeia `?`.
- [ ] `A?C` relaciona posições conhecidas; `???`/`A??` são rejeitadas.
- [ ] `\?` é literal e `\\` é barra; escape inválido é rejeitado.
- [ ] Sem wildcards habilitados, `?` continua literal.
- [ ] Custom sequence `ABCDE`, query `ABC`, encontra candidato deslocado.
- [ ] Sequência Unicode funciona por code points; duplicatas/ausências são erros.
- [ ] Value Scan `0x10 0x11 0x12` e `16, 17, 18` têm a mesma relação.
- [ ] `12foo`, negativos/overflow não iniciam job; não há mappings fabricados.
- [ ] Repetir wildcard/custom/value em 16-bit LE e BE com fixtures sintéticas.

## Create Table Assistant

- [ ] Relative Search → selecionar resultado → Create Table mostra offset, bytes e origem.
- [ ] Nenhum candidato começa aprovado; editar texto remove sua aprovação anterior.
- [ ] Cancel/Escape preservam a tabela, histórico e Modified.
- [ ] Selecionar subconjunto, Review changes e Apply importam somente o aprovado.
- [ ] Complementar preserva caminho, nome, comentários e entradas não relacionadas.
- [ ] Conflitos exigem Replace explícito; duplicatas/texto ambíguo bloqueiam Apply.
- [ ] Criar tabela nova protege alterações não salvas com Save/Don't Save/Cancel.
- [ ] 16-bit LE preserva bytes físicos (valor 8140 → chave 4081); BE mantém 8140.
- [ ] Wildcards importam só posições conhecidas; Value Scan explica ação indisponível.
- [ ] Um Undo desfaz a importação inteira; Redo reaplica; Save/Save As salva corretamente.
- [ ] Nova tabela é Untitled.tbl, sem caminho, Modified; não houve escrita na ROM.

## String Scanner

### Known-Text Discovery

- [ ] Abrir fixture e pesquisar palavras/frases por Exact Encoding e Loaded Table.
- [ ] Comparar com Relative 8/16-bit LE/BE; verificar wildcards/sequência customizada.
- [ ] Executar múltiplas linhas e conferir grupos, origem, bytes e contexto limitado.
- [ ] Verificar erros de encoding/tabela sem substituição silenciosa.
- [ ] Abrir Create Table a partir de mappings relativos e conferir aprovação manual/conflitos.
- [ ] Cancelar, trocar ROM e confirmar ausência de dados anteriores.
- [ ] Confirmar limite global e não interpretar consultas não executadas como sem matches.

### Text Browser

- [ ] Abrir binário sintético pelo diálogo nativo e executar String Scanner.
- [ ] Alternar para Text Browser durante a busca e acompanhar batches/progresso.
- [ ] Selecionar candidato, conferir metadata, preview e evidências.
- [ ] Verificar aviso de preview truncado e análise parcial.
- [ ] Testar confiança/encoding/comprimento e busca literal no preview; restaurar filtros.
- [ ] Conferir seleção preservada quando visível e removida quando filtrada.
- [ ] Testar ordenações, Previous/Next text, setas, Home/End e páginas.
- [ ] Cancelar, fechar documento e abrir outro sem resultados/seleção anteriores.
- [ ] Confirmar que abrir browser não inicia scan nem altera o arquivo.

- [ ] Executar scanner ASCII em binário sintético com frase, repetição e palavra curta.
- [ ] Confirmar classificação, evidências, encoding e comprimentos em bytes/caracteres.
- [ ] Selecionar candidato e inspecionar métricas; confirmar aviso em preview truncado.
- [ ] Filtrar por confiança, comprimento, letras e repetição; limpar e recuperar originais.
- [ ] Confirmar que Hide decoding errors não inventa falhas em candidatos estritos.
- [ ] Verificar japonês sem espaços, cancelamento e fechamento sem jobs pendentes.

- [ ] ASCII mínimo 4 encontra `HELLO`: offset `1`, 5 caracteres/5 bytes.
- [ ] Fixture Windows-1252 com `80` e aspas/travessões decodifica corretamente.
- [ ] Shift-JIS mínimo 2 encontra `82 A0 82 A2` = `あい`, 2 caracteres/4 bytes.
- [ ] CP437/CP850 respeitam encoding selecionado, sem fallback silencioso.
- [ ] Espaços/números/pontuação habilitados integram strings; desabilitados delimitam.
- [ ] Mínimo/máximo contam code points; string longa demais é excluída inteira.
- [ ] Bytes inválidos/multibyte incompleto no EOF não fabricam caracteres.
- [ ] Preview longo indica truncamento e preserva comprimento total.

## Jobs, resultados e erros

- [ ] Progresso/lotes aparecem durante busca; UI permanece responsiva.
- [ ] Cancel termina como cancelled, não erro; nova busca funciona.
- [ ] Buscar A, cancelar e buscar B não mistura eventos antigos.
- [ ] Paginação limita linhas no DOM e mantém contagem correta.
- [ ] Seleção preserva offset/length, sem alterar binário ou tabela.
- [ ] Max Results não inventa 100% quando backend parou antes.
- [ ] `100`/`0x100` são hex; `0xZZ`, `-1`, `12foo` são rejeitados.
- [ ] Range/alignment inválidos e limites excessivos exibem erros sem stack.
- [ ] Fechar/reabrir painel remove listeners; eventos não duplicam.
- [ ] Labels, teclado, foco e estados são legíveis sem depender apenas da cor.
- [ ] Console sem exceções na abertura, cancelamento, nova busca e fechamento.
- [ ] Hash e tamanho do binário original permanecem idênticos.

## Gate de publicação

- [ ] Typecheck, lint, testes, build, Prettier e `git diff --check` aprovados.
- [ ] Roteiro manual registrado e falhas bloqueadoras resolvidas.
- [ ] Aplicativo empacotado inicia e resolve worker, não apenas desenvolvimento.
- [ ] Instalação/atualização e ícones verificados na plataforma publicada.
- [ ] README, About, package/lockfile e notas usam mesma versão.
- [ ] Autorização explícita antes de commit/tag/release/publicação.
