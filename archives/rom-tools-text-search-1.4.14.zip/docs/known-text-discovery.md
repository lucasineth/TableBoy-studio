# Known-Text Discovery — candidata v1.4.14 (não publicada)

## Uso e estratégias

ROM Tools → Text Search → Known-Text Search. Informar uma palavra/frase por linha,
selecionar estratégia e acionar Search explicitamente. Espaços de cada linha são
preservados; linhas vazias são ignoradas. Consultas idênticas continuam como grupos
separados, identificados pela posição no lote. Não há normalização Unicode.

- Exact Encoding: codec estrito existente para Windows-1252, CP437, CP850 ou Shift-JIS,
  seguido de BinarySearchEngine. ASCII utiliza o TableEncoder/TableDecoder com as
  128 associações padronizadas ASCII, sem novo codec público. Texto não representável
  produz erro explícito, nunca substituição silenciosa.
- Loaded Table: TableSearchEngine recebe snapshot das entradas e nome da tabela no
  início do job. Tokens, Unicode e chaves variáveis seguem o codec existente.
- Relative Search: mesma engine e opções atuais para largura 8/16-bit, byte order
  explícito, wildcard `?` com `\?` literal e sequência customizada. Não usa TableEncoder.
  Value Scan permanece no modo Relative Search original; aqui as consultas são texto.

Uma estratégia é executada por lote. Para comparar métodos, repetir explicitamente
as consultas com outra estratégia. A busca anterior é substituída, como nos demais
modos; não há histórico comparativo persistente. Auto Strategy é opcional na
especificação e **não foi implementada**. Nenhum encoding/endianness é autodetectado.

## Arquitetura

`KnownTextSearch` é composição no core, não um novo algoritmo de matching.
`KnownTextTypes` contém contratos serializáveis e limites; não importa engines no
Renderer. O request `known` percorre o mesmo IPC autorizado por owner/documentId,
Coordinator, fila FIFO, sessão persistente e worker. Não há worker/canal adicional,
leitura da ROM pelo Renderer ou chamadas repetidas a binary:read-range.

As consultas são executadas sequencialmente no mesmo job. Batches preservam query,
queryIndex, offset absoluto, length em bytes, método, decoder/label da tabela e,
somente quando produzidos pela engine relativa, mappings + largura/byte order.
O Text Browser continua aceitando somente origem String Scanner; não mistura matches
conhecidos com candidatos/classificações do Text Candidate Analyzer.

## Limites, progresso e erros

Política IPC centralizada em `KNOWN_TEXT_LIMITS`: até 16 consultas, 512 unidades
UTF-16 por consulta, 4096 combinadas, 1000 resultados no total do lote e contexto de
0–128 bytes por lado. Reutiliza validações de range, alignment e TableEntry existentes.
Páginas de 100 resultados; batches seguem as engines, com até 128 itens.
Preview de bytes do match limitado a 1024 bytes, com flag explícita de truncamento;
offset/length continuam descrevendo o match completo. Consultas relativas limitadas
a 512 símbolos ocupam no máximo 1024 bytes, preservando os bytes usados pelo assistente.

Progresso agregado pondera cada consulta igualmente. `processed` é o equivalente do
range em bytes multiplicado pela fração de progresso da engine, não uma nova medição
de bytes físicos lidos. O total é range × quantidade de consultas. Limite global pode
encerrar antes de pesquisar consultas posteriores, sem inventar 100%.

Cancelamento usa o contrato existente backed por Atomics e também é verificado
entre consultas e ao enriquecer cada resultado. Fechar/trocar ROM e eventos antigos
mantêm o lifecycle existente. Um erro interrompe o lote (fail-fast); matches já
recebidos continuam visíveis. Erros de codec conservam código, posição, fragmento
e motivo quando disponíveis. Não há retry nem avanço silencioso após erro.
Contagens por grupo são matches recebidos; zero não prova que aquele grupo foi
inteiramente pesquisado quando ocorreu cancelamento, erro ou limite global.

## Contexto e mappings

Contexto é opt-in no core; UI começa com 16 bytes por lado. É truncado pelo range
da busca e pelos limites do arquivo. Preview usa decoder estrito de encoding/tabela
somente quando aplicável. Se o range começar no meio de uma chave multibyte ou tiver
bytes desconhecidos, o decode pode falhar: o match permanece válido com bytes e
código da falha. Não há sincronização heurística de boundaries. Contexto não prova
que bytes vizinhos pertençam ao mesmo texto. Relativo retorna apenas contexto binário,
sem presumir encoding desconhecido.

Mappings relativos são observações candidatas, não confirmadas. Wildcards não
produzem mappings. Exact/Loaded Table não inventam associações. Create Table abre
o assistente existente para selecionar/corrigir/aprovar individualmente; conflitos
e substituições exigem revisão. Aplicação preserva a transação Undo/Redo existente
e não salva `.tbl` automaticamente. Nunca gera alfabetos ausentes ou escreve na ROM.

## Limitações

Busca relativa exige relações numéricas compatíveis (deslocamento modular comum),
não uma substituição arbitrária. Encodings proprietários, strings fragmentadas,
códigos de controle, compressão e criptografia podem impedir correspondências.
Uma correspondência pode ser falso positivo e não confirma diálogo ou charmap.
Não há OCR, ponteiros, descompressão, Hex Viewer ou edição/reinserção.
