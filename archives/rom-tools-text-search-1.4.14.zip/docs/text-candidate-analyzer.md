# Text Candidate Analyzer — etapa interna v1.4.12

## Fluxo e limites

O String Scanner existente continua decodificando com codecs estritos. Seu lote é
enriquecido por `analyzeStringBatch` no worker persistente, antes de atravessar o
Coordinator/IPC. Não há scanner paralelo, cópia de ROM ou leitura extra de contexto.
Apenas o byte imediatamente após o candidato, dentro do range autorizado, pode
ser consultado para indícios de NUL ou quebra de linha. EOF e fim do range são
limites, não prova de terminador. Esses indícios **não aumentam a confiança**.

Cada análise examina até 256 code points do preview já existente. O comprimento
completo continua disponível em `characterLength` e `length` (bytes). `scope` é
`preview` quando a análise é parcial; todas as proporções descrevem apenas o
texto analisado, nunca a ROM ou a string completa não exibida.
Os bytes de preview não são recopiados para analisar. Batches continuam limitados
a 128 resultados e a política IPC continua limitando resultados a 10.000.
Cancelamento é verificado antes de cada análise, além das verificações do scanner.

## Métricas e regras determinísticas

- Letras/marcas: categorias Unicode L/M; números N; pontuação P; símbolos S;
  espaços Zs. Não há normalização ou exigência de palavras/espaços latinos.
- Caracteres C (controles, formatos, surrogates etc.) são tratados conservadoramente
  como não imprimíveis. Printable ratio = (caracteres analisados − C) / total.
- Diversidade: símbolos distintos / total, sem case folding.
- Repetição alta: pelo menos 4 caracteres e símbolo dominante ≥ 75%, ou maior run
  idêntico ≥ max(4, metade do total), ou run periódico de período 1–8 ocupando
  pelo menos 8 caracteres e 60% do total. Não é uma regra de linguagem natural.
- Low: comprimento completo menor que 8, repetição alta, controles, erro reportado,
  ausência de texto fora de tokens conhecidos ou proporção L/M menor que 20%.
- High, se não Low: totalmente imprimível, L/M ≥ 45%, diversidade ≥ 30% e símbolos
  ≤ 15% em CP437/CP850, ≤ 40% em Shift-JIS ou ≤ 30% nos demais perfis.
- Medium: demais casos. Cada fator relevante é apresentado como evidência.

OEM contém caracteres gráficos, por isso possui limite de símbolos mais conservador.
Hiragana, Katakana e Kanji contam como letras. Japonês não precisa conter espaços;
textos curtos japoneses recebem o mesmo aviso de baixa seletividade que menus latinos.
Os limiares são heurísticos, não um modelo estatístico calibrado. Não existe
porcentagem de certeza; porcentagens na UI são apenas proporções medidas do texto.

## Filtros e interface

Filtros atuam em uma lista derivada, sem modificar/remover os resultados originais.
Minimum confidence é inclusiva (Medium também mostra High); mínimo de caracteres
usa o comprimento completo. Letras/repetição/erros usam a análise do preview.
Clear filters restaura todos os resultados. Uma nova busca reinicia os filtros.
Resultado selecionado mostra métricas e todas as evidências; selecionados ocultos
pelo filtro não mostram detalhes até voltarem a ser visíveis.

O scanner estrito encerra runs diante de controles e sequências inválidas, portanto
esses erros não são entregues como candidatos. Hide decoding errors normalmente
não altera a lista atual. O analisador aceita metadados explícitos de erros e tokens
para consumidores do core, sem inventar tokens a partir de colchetes. Tokens
explicitamente conhecidos são excluídos das proporções e da repetição; o comprimento
original é preservado. O String Scanner **não utiliza `.tbl`** nesta etapa; não há
nova integração automática com Table Search nem inferência de tokens/terminadores.

## Falsos positivos e falsos negativos

- Dados comprimidos/cifrados e tabelas proprietárias podem esconder textos reais.
- Menus curtos legítimos podem receber Low; números ou pontuação podem ser legítimos.
- Strings naturais também podem ser fragmentos binários aleatórios.
- Repetição pode ser deliberada; previews parciais podem não representar o restante.
- Não há análise de ponteiros, OCR, IA, criação de tabelas ou escrita de ROM.

Melhorias futuras possíveis: perfis linguísticos explicitamente selecionados,
estatísticas acumuladas durante o scanner para strings longas e integração assistida
com textos decodificados por `.tbl`, sem classificá-los como diálogos confirmados.
