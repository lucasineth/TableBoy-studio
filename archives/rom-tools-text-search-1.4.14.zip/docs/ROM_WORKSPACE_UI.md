# ROM Analysis Workspace — redesign visual

## Auditoria e decisões

A implementação anterior combinava toolbar global do editor, botão de retorno,
abas internas de ROM Tools, título e barra de arquivo. O grid de ROM Tools possuía
três linhas explícitas para até quatro blocos, deixando altura distribuída de forma
inconsistente. Agora há uma única navegação principal e um shell flex com área
restante bem definida, sem depender da quantidade de blocos visíveis.

- Navegação: Table Editor / Text Search / Text Browser.
- Menu de aplicação e seus comandos/atalhos preservados.
- Toolbar do editor fica disponível apenas no contexto Table Editor.
- ROM Tools exibe ferramenta ativa, nome, tamanho, read-only e Replace/Close em uma
  barra compacta; não há caminho completo ou metadata duplicada.
- Estado vazio sem card, borda, ícone ou ilustração, com descrição curta e ação Open.
- Text Search: formulário rolável à esquerda e resultados com paginação à direita.
- Text Browser: controles compactos, lista e inspector separados por divisor discreto.
- Não foram adicionados splitters: os dois painéis já aproveitam a largura disponível.
- Os workspaces permanecem montados ao alternar, preservando configuração, filtros
  e seleção. Escape cancela busca somente quando ROM Tools está ativo.
- Ctrl+F foca o campo do workspace ativo (preview no Browser, query/opções no Search,
  busca de tabela no editor). Demais atalhos existentes foram preservados.

## Escopo dos arquivos

Criado `src/renderer/src/components/WorkspaceNavigation/WorkspaceNavigation.tsx`.
Modificados `App.tsx`, `features/rom-search/RomSearchPanel.tsx`,
`features/text-browser/TextBrowserPanel.tsx` e `assets/main.css`, todos sob
`src/renderer/src/`, além de README e documentação do Text Browser.

Core, modelos de documentos, codecs, IPC, worker, classificação e algoritmos de
busca não foram modificados nesta etapa. Nenhuma dependência, funcionalidade de
escrita ou nova ferramenta foi adicionada. A versão permanece 1.4.13; sem commit/release.

## Validação

- 310/310 testes automatizados existentes aprovados.
- TypeScript, ESLint, build Electron/Vite, Prettier e `git diff --check` executados.
- A revisão React manteve identidade dos componentes e lifecycle existente, com
  navegação acessível, toolbar contextual e ausência de análise pesada no Renderer.
- Bundle real executado no Electron, com Main/preload/IPC/worker existentes.
- UI acionada via CDP; um adaptador temporário selecionou somente fixtures sintéticas.
  Isso **não é validação manual do diálogo nativo**. Sua seleção manual permanece
  pendente, assim como homologação humana em escalas de DPI e sistemas diferentes.

Viewports Electron configuradas por CDP (não dimensões externas da janela):

| Viewport  | Altura do workspace | Altura da lista do Browser | Overflow horizontal global |
| --------- | ------------------- | -------------------------- | -------------------------- |
| 1366×768  | 699 px              | 385 px                     | Não                        |
| 1280×720  | 651 px              | 352 px                     | Não                        |
| 1920×1080 | 1011 px             | 697 px                     | Não                        |

Conferidos: estado sem ROM, Table Search, Relative Search 8-bit, String Scanner,
Text Browser, filtros, inspector, retorno ao editor, contexto preservado entre
ferramentas, cancelamento após progresso em 64 MiB, troca/fechamento e reabertura
sem resultados antigos. A rolagem local do formulário alcançou o botão Search.
Captura visual de Text Browser em 1366×768 inspecionada. Não foram registradas
exceções do Renderer nas verificações funcionais.

Relative 16-bit LE/BE, modos avançados e Create Table continuam cobertos pela suíte
automatizada; não foi repetida sua homologação manual nesta etapa visual.

Os três fixtures mantiveram os hashes SHA-256 antes/depois; nenhuma escrita de ROM:

- synthetic.bin: `24981df58f83f1a7d1a03f8bd30b73076bebd0223cdaa95d41f8e7ada8c96937`
- large.bin: `dbfaca2662cb70b69dfefd5ac95d1f54a73663092d46cefdc9609dc695a12c98`
- other.bin: `5adf016bdd071bdd8be9efbe92899db2c4047dab05b54ee79c14411c6e45ea38`

Scripts, adaptador, capturas e binários temporários foram removidos após validação.
Não foi utilizada ROM comercial. Limitações de previews e `.tbl` do String Scanner
permanecem as mesmas da v1.4.13.
