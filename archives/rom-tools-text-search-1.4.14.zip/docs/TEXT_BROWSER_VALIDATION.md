# Validação — Text Browser v1.4.13

## Resultado automatizado

310/310 testes aprovados, incluindo 17 novos para o Text Browser. Cobertura:
adaptação sem cópia de buffers/análise, identidade estável, ordenações, filtros
reversíveis, pesquisa literal no preview, seleção, anterior/próximo, paginação de
10.000 candidatos com 100 linhas por página, resultados parciais e incrementais,
cancelamento, eventos antigos, fechamento/troca de ROM e falha de worker.

TypeScript, ESLint, build Electron/Vite, Prettier e `git diff --check` foram
executados. O lint foi repetido isoladamente após uma corrida com arquivo
temporário do Vite durante build paralelo. O build final precisou de execução
fora do sandbox após erro de acesso do esbuild à configuração local. Nenhuma
configuração foi alterada para contornar essas condições do ambiente.

## Electron — evidência ponta a ponta

O bundle real foi executado com Main, preload, IPC, Coordinator, worker e codecs
existentes. Controles React foram acionados por CDP, sem chamadas diretas ao scanner.
Um adaptador temporário do diálogo selecionou somente fixtures sintéticas locais.
Isso **não equivale a uma validação manual do diálogo nativo**: a tentativa de
inspecionar seus controles pela automação do desktop não obteve acesso utilizável.
Essa etapa manual permanece pendente, assim como avaliação visual por usuário.

Confirmado no Electron:

- String Scanner entregou 304 candidatos em três lotes do pipeline existente.
- Text Browser exibiu somente candidatos do scanner, no máximo 100 por página.
- Seleção apresentou metadata, texto, métricas e evidências existentes no inspector.
- Filtro textual preservou a seleção visível e removeu a seleção ocultada.
- Reset restaurou resultados originais sem iniciar outra busca.
- Paginação, Next text, ArrowUp, Home/End e ArrowDown atravessando página foram
  acionados. O foco permaneceu na lista ao trocar página via teclado.
- Preview truncado mostrou aviso de texto parcial.
- Troca de arquivo limpou candidatos anteriores e manteve o novo estado Idle.
- Em 64 MiB, cancelamento após progresso terminou como Cancelled.
- Nova busca seguida de Close ROM limpou a interface durante execução.
- Outro arquivo só apresentou seu único candidato após Search explícito.
- Não foram registradas exceções no Renderer durante essas verificações.
- Hashes SHA-256 antes/depois permaneceram idênticos:

| Fixture       | SHA-256                                                            |
| ------------- | ------------------------------------------------------------------ |
| synthetic.bin | `6f2a48c6dde7c61a7eaee33897171de38c04fe5b2d119199dc96c4af644d0c6d` |
| large.bin     | `dbfaca2662cb70b69dfefd5ac95d1f54a73663092d46cefdc9609dc695a12c98` |
| other.bin     | `2d9c4282423d39ca43ddb15d056352df86e9c6ad3eb26c13cbb6b73b427bc3ed` |

O adaptador, scripts e fixtures temporários foram removidos. Nenhuma ROM comercial
foi utilizada, modificada ou incluída no projeto.

## Arquivos desta etapa

Criados:

- `src/renderer/src/features/text-browser/textBrowserModel.ts`
- `src/renderer/src/features/text-browser/TextBrowserPanel.tsx`
- `src/renderer/src/features/rom-search/CandidateFilterControls.tsx`
- `test/renderer/textBrowser.test.mts`
- `docs/text-browser.md`
- `docs/TEXT_BROWSER_VALIDATION.md`

Modificados:

- `src/renderer/src/features/rom-search/CandidateResults.tsx`: extração/reutilização
  dos filtros e exposição do componente de detalhes existente.
- `src/renderer/src/features/rom-search/RomSearchPanel.tsx`: navegação das ferramentas
  e compartilhamento da sessão/documento, progresso e erros.
- `src/renderer/src/assets/main.css`: estilos locais compactos para lista/inspector.
- `package.json`, `package-lock.json`,
  `src/renderer/src/components/AppDialog/AppDialog.tsx`: candidata 1.4.13 não publicada.
- `README.md`, `CHANGELOG.md`, `docs/REGRESSION_CHECKLIST.md`: documentação.

As alterações anteriores não relacionadas foram preservadas. Nenhuma dependência,
IPC, worker, algoritmo de busca, decoder ou regra de classificação foi acrescentado.
Não houve commit, tag ou release.

## Limitações e próximos passos

Somente a sessão corrente do String Scanner é apresentada. Não há `.tbl`, arquivo
de sessões ou recuperação de string completa além do preview. Confidence permanece
heurística e falsos positivos/negativos continuam possíveis. O scanner estrito não
retorna candidatos com sequências inválidas; a UI mostra apenas erros disponíveis.

Ficam para planejamento separado: origem `.tbl` explícita, leitura limitada de
texto completo e eventual histórico de sessões com política de memória. A validação
manual pelo diálogo nativo, acessibilidade com leitor de tela e outras escalas de
tela/sistemas permanecem no checklist. O Text Browser complementa o String Scanner;
não o substitui e não escreve no binário.
