# Validação — Create Table Assistant v1.4.11

## Escopo e ambiente

Windows, Node v24.18.0, Electron do projeto. Testes com bytes sintéticos gerados
localmente, sem fixtures comerciais. Nenhum código de busca, codec ou IPC foi
modificado para implementar o assistente.

## Integração no Electron

Fluxo executado no build Electron/Vite, controlando os componentes React:

1. Open Binary → Relative Search → selecionar resultado → Create Table.
2. Confirmar Candidate e zero associações previamente aprovadas.
3. Selecionar New table, aprovar cada associação e executar Review changes.
4. Apply → verificar Modified e os valores no grid.
5. Um Undo remove todas as associações; Redo restaura o conjunto.
6. Save → verificar conteúdo `.tbl` e estado Saved.

Resultados verificados:

| Busca          | Offset | Bytes encontrados | Chaves salvas    |
| -------------- | ------ | ----------------- | ---------------- |
| ABC, 8-bit     | 1      | 81 82 83          | 81, 82, 83       |
| ABC, 16-bit LE | 5      | 40 81 41 81 42 81 | 4081, 4181, 4281 |
| ABC, 16-bit BE | 12     | 81 40 81 41 81 42 | 8140, 8141, 8142 |

Também confirmado: sair e voltar ao painel conserva a origem BE; Cancel no
Mapping Inspector não altera entradas nem o título Saved do documento.

O teste usou um harness temporário que restringia as respostas dos diálogos de
seleção/salvamento aos arquivos sintéticos. Main, preload, IPC, ownership, worker,
filesystem e lógica do editor eram reais. O harness e os arquivos foram removidos.
Não se trata de validação humana completa dos diálogos nativos: essa parte, assim
como o teste de instalador, permanece pendente no checklist de regressão.

## Cobertura automatizada acrescentada

16 testes de extração/revisão/importação: aprovação explícita, seleção parcial,
LE/BE, round-trip codec/save, wildcards, Value Scan sem mappings, repetições,
conflitos, duplicatas, atomicidade, Unicode exato, cancelamento sem mutação,
preservação de entradas e histórico/metadata de documentos novos e existentes.

1 teste de proveniência da busca: conclusão/seleção conservam width/byte order;
novo run ou fechamento de documento limpam a origem.

Verifique os resultados dos comandos na entrega desta etapa; o checklist manual
não foi marcado automaticamente como concluído.
