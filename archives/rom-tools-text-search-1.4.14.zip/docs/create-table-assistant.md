# Create Table Assistant — etapa v1.4.11

Selecione um resultado da Relative Search e clique em **Create Table**. A ação
abre um diálogo contextual e não altera a tabela automaticamente. Não existe
inferência de alfabetos, caracteres ausentes, pontuação, encodings ou ponteiros.

## Revisão

- As associações começam como Candidate, sem aprovação.
- Edite o texto e marque Approve individualmente; editar novamente remove aprovação.
- Complement current table preserva nome, caminho e entradas não relacionadas.
- New unsaved table usa proteção de alterações não salvas antes de substituir
  o documento atual. Cancelar essa proteção mantém o diálogo e a tabela intactos.
- Larguras diferentes não são mescladas: nesse caso crie uma tabela nova.
- Chaves ocupadas divergentes exigem Replace existing entry explícito.
- Associações idênticas não sobrescrevem comentários. Uma complementação composta
  apenas de associações idênticas não cria histórico nem marca Modified.
- Chaves/textos duplicados na seleção e texto já associado a outra chave são
  rejeitados para não introduzir ambiguidade no TableEncoder.
- Review changes mostra a seleção aprovada e contagens de adições, substituições
  e associações idênticas. Apply approved mappings é a confirmação final.
- Cancel, Escape e fechamento do diálogo não alteram o documento.

## Chaves e evidências

São usados somente os mappings retornados pela engine ou corrigidos manualmente.
Wildcards não geram mappings. Value Scan não possui mappings de caracteres, por
isso Create Table fica indisponível com explicação.

8-bit preserva o byte. 16-bit preserva a ordem física da sequência pesquisada:
valor `8140` → chave `8140` em BE ou `4081` em LE. O grid representa a chave `.tbl`,
não o valor uint16 da busca. O diálogo informa largura, byte order, offset e bytes
originais. Não há autodetecção de endianness.

## Transação e salvamento

Extração, validação de conflitos e preparação atômica ficam no core/table;
React apresenta a revisão. Apply revalida contra o documento atual, importa somente
associações aprovadas em uma transação Undo/Redo e marca Modified. Na criação, Undo
retorna à nova tabela vazia; não recupera o documento substituído. Na complementação,
Undo restaura todas as entradas anteriores. Redo reaplica a importação inteira.

Nada é gravado durante a importação. Use Save/Save As do editor para salvar `.tbl`.
A ROM permanece somente leitura. Nenhum algoritmo de busca, codec ou IPC novo é
necessário. A origem 8/16-bit LE/BE fica associada ao run, e não às opções que o
usuário venha a editar depois.
