<p align="center">
  <img src="build/icon.png" width="220" alt="TableBoy Studio">
</p>

<h1 align="center">TableBoy Studio</h1>

<p align="center">
  Editor desktop de tabelas <code>.tbl</code> e ferramentas de busca de textos em binários.
</p>

<p align="center"><strong>Electron · React · TypeScript · Vite</strong></p>

## Estado da versão

Este código prepara a **v1.4.14**, ainda não publicada. A release pública existente
é a [v1.1.0](https://github.com/lucasineth/TableBoy-studio/releases/tag/v1.1.0).
As etapas v1.2–v1.4.14 representam desenvolvimento interno, não releases separadas.
Consulte o [changelog](CHANGELOG.md) e o [checklist de regressão](docs/REGRESSION_CHECKLIST.md).

## Sobre o projeto

O TableBoy Studio permite criar, abrir, editar, validar e salvar tabelas que
associam chaves a caracteres, strings ou tokens. Também abre binários para análise
e busca de textos, **somente leitura**: nenhuma ferramenta salva, edita ou aplica
patches na ROM original. Testes e benchmarks usam dados sintéticos; nenhuma ROM
comercial acompanha o aplicativo.

O projeto é inspirado conceitualmente no Table Manager 1.0 de Hyllian, mas possui
implementação própria, interface original e arquitetura moderna.

## Funcionalidades implementadas

A navegação principal reúne **Table Editor · Text Search · Text Browser**. O editor
mantém sua toolbar; ROM Tools usa uma barra contextual com arquivo, tamanho,
estado read-only e ações de substituir/fechar. Painéis preservam contexto ao alternar
ferramentas e usam rolagem localizada. Veja a [validação do layout](docs/ROM_WORKSPACE_UI.md).

### Table Editor e Character Picker

- Matriz hexadecimal 16×16: linha = nibble alto, coluna = nibble baixo.
- Tabelas 8-bit (`00–FF`) e 16-bit (`0000–FFFF`), com detecção de modo.
- Paginação 16-bit sem renderizar todas as 65.536 células.
- New, Open, Save, Save As e Drag & Drop de arquivos `.tbl`.
- Unicode, strings e tokens; edição pela matriz ou Character Inspector.
- Character Catalog com letras, números, PT-BR e conjuntos japoneses.
- Picker individual: cada escolha altera **somente a célula selecionada**;
  o catálogo não associa caracteres a bytes fixos.
- Undo/Redo, busca de entradas, validação, estatísticas e proteção contra perda
  de alterações ao criar/abrir tabelas ou fechar a janela.

### Codecs e encodings

- `TableEncoder` e `TableDecoder`: texto ⇄ bytes usando `TableEntry[]` no core.
- Chaves variáveis, tokens, longest-match e erros estruturados.
- Windows-1252, CP437, CP850 e Shift-JIS estritos.
- Normalização explícita: `none` (padrão), NFC, NFD, NFKC e NFKD.
- Utilitários de uint16 little-endian e big-endian no core.

Codec de tabela e encoding conhecido são responsabilidades separadas. Windows-1252
não é Latin-1, “ANSI” não é um encoding único e Shift-JIS não substitui uma `.tbl`
proprietária. Não há normalização Unicode implícita. Encodings estão disponíveis
no core e no String Scanner; ações dedicadas de conversão no menu Encoding ainda
estão desabilitadas.

### ROM Tools → Text Search

- **Known-Text Search**: consultas por palavra/frase, uma por linha, executadas
  sequencialmente por Exact Encoding, Loaded Table ou Relative Search no worker
  existente. Resultados preservam consulta/método, bytes e contexto limitado;
  mappings relativos podem ser revisados no Create Table Assistant.
  Não é detecção universal de charmap. Veja [Known-Text Discovery](docs/known-text-discovery.md).

- Abertura/fechamento pelo diálogo nativo do Electron; nome e tamanho do binário.
- Table Search utiliza a tabela atual para codificar a query e buscar os bytes.
- Contexto opcional; falha ao decodificar contexto não invalida o match.
- Relative Search 8-bit e 16-bit LE/BE explícitos, com mappings bijetivos.
- Advanced Relative Search: wildcards, Custom Character Sequence e Value Scan.
- Ranges, alignment, limite de resultados, progresso e cancelamento real.
- Lotes incrementais, paginação e seleção; offsets são offsets de arquivo em bytes,
  não endereços de CPU ou bancos.
- Create Table Assistant (etapa v1.4.11): revisão manual dos mappings da Relative
  Search, criação de tabela nova ou complementação da atual, conflitos explícitos
  e importação atômica com Undo/Redo. Nada é salvo automaticamente. Consulte
  [o assistente](docs/create-table-assistant.md).

Relative Search usa domínio modular (256 ou 65.536). Símbolos conhecidos mantêm
um deslocamento comum; wildcards ocupam um valor e não geram mappings. Com a opção
habilitada, `?` é desconhecido, `\?` é literal e `\\` representa barra invertida.
São necessárias duas posições conhecidas; queries de dois símbolos exigem opção
explícita. Custom Character Sequence define relações pela posição dos símbolos,
não os bytes reais. Value Scan aceita decimal ou hex com prefixo `0x`, separados
por espaços/vírgulas, e não fabrica mappings de caracteres.

### String Scanner

ROM Tools → **Text Browser** organiza os resultados da sessão atual do String
Scanner em lista paginada e inspector. Permite filtros reversíveis, pesquisa
literal no preview, ordenação por offset/comprimento/confiança e navegação por
teclado. Usa os mesmos previews e análises do worker, sem nova varredura,
decodificação `.tbl` ou leitura adicional. Consulte [Text Browser](docs/text-browser.md).

Text Candidate Analyzer acrescenta classificação heurística Low/Medium/High,
métricas Unicode e evidências aos previews no worker. Filtros de confiança,
comprimento, letras, repetição e erros afetam somente a visualização; limpar
restaura os resultados originais. Confiança não é probabilidade de diálogo real.
Análise de strings truncadas é parcial. Consulte
[as regras e limitações](docs/text-candidate-analyzer.md).

- ASCII imprimível, Windows-1252, CP437, CP850 e Shift-JIS.
- Sequências contíguas permitidas, com validação multibyte estrita.
- Mínimo padrão: 4 code points; máximo opcional e filtros de espaços, números
  e pontuação/símbolos. Categorias desabilitadas delimitam strings.
- Comprimentos em caracteres e bytes separados; máximo exclui a sequência longa
  inteira, sem dividi-la.
- Previews limitados a 256 code points e 512 bytes, sem cortar caracteres.

Resultados são candidatos legíveis, não prova de diálogo. O scanner não descobre
encodings ou tabelas proprietárias automaticamente. Consulte
[String Scanner](docs/string-scanner.md) para a semântica completa.

## Formato `.tbl`

Uma chave hexadecimal por linha, seguida de `=` e seu valor:

```text
41=A
42=B
43=C
F1=Ã
F2=Õ
F4=ã
F5=õ
```

Exemplo separado de tabela 16-bit:

```text
8140=あ
8141=い
F001=[PLAYER]
```

Arquivos são lidos/salvos como UTF-8 sem conversão implícita de encoding. O parser
reconhece comentários `#`, `;` e `//`, e informa erros de linha/chave. O editor
visual exige chaves uniformes de um ou dois bytes e rejeita misturas incompatíveis.
Parser e codecs do core aceitam chaves variáveis; isso não significa que o grid
edite documentos de largura variável.

## Arquitetura e segurança

```text
src/
├── core/
│   ├── table/           # Documento, parser, writer e validação
│   ├── characters/      # Catálogo sem associações fixas
│   ├── codec/           # Codec de tabelas
│   ├── encoding/        # Encodings conhecidos e normalização
│   ├── bytes/           # Endianness
│   ├── binary/          # BinaryDocument read-only
│   └── search/          # Engines síncronas independentes da infraestrutura
├── main/
│   ├── ipc/             # Arquivos .tbl
│   ├── binary/          # Registry, ownership e lifecycle
│   └── search/          # Coordinator, worker, protocolo e Search IPC
├── preload/             # APIs mínimas via contextBridge
├── renderer/src/        # React, editor e ROM Search
└── shared/              # Contratos de IPC
```

```text
Renderer → Preload/contextBridge → IPC → Main → Filesystem
Search IPC → autorização no Registry → Coordinator → Worker → Core search
```

`contextIsolation: true` e `nodeIntegration: false` são preservados. Renderer não
recebe filesystem, Node.js, `ipcRenderer`, caminhos arbitrários ou a ROM inteira.
Documentos/jobs pertencem ao `webContents` que fez a chamada; IDs não concedem
acesso entre janelas. Leituras binárias via IPC são limitadas a 64 KiB.

Worker persistente reutiliza sessões entre buscas. A fila é FIFO; progresso/lotes
atravessam protocolo tipado. Cancelamento usa flag compartilhada com Atomics,
observável durante execução síncrona. Fechar documentos/janelas libera sessões e
cancela jobs. Não há ACK/backpressure ou worker pool.

## Atalhos

| Ação                      | Atalho       |
| ------------------------- | ------------ |
| Nova tabela               | Ctrl+N       |
| Abrir tabela              | Ctrl+O       |
| Salvar                    | Ctrl+S       |
| Salvar como               | Ctrl+Shift+S |
| Desfazer                  | Ctrl+Z       |
| Refazer                   | Ctrl+Y       |
| Buscar na tabela          | Ctrl+F       |
| Limpar célula selecionada | Delete       |
| Exibir atalhos            | F1           |

## Instalação e desenvolvimento

Use Node.js **22.18+ ou 24 LTS** e npm: testes executam TypeScript com
`--experimental-strip-types`. Desenvolvimento validado no Windows; scripts para
macOS/Linux existem, mas isso não equivale a validação nessas plataformas.

```bash
git clone https://github.com/lucasineth/TableBoy-studio.git
cd TableBoy-studio
# Enquanto a candidata estiver nesta branch:
git checkout lucas.ineth
npm ci
npm run dev
```

### Validação e build

```bash
npm run typecheck
npm run lint
npm test
npm run build
npx prettier --check .
git diff --check
```

Build gera Main, Preload, worker e renderer em `out/`, não um instalador.
`npm start` executa o preview Electron após o build.

Benchmarks são separados da suíte normal:

```bash
npm run benchmark:search
npm run benchmark:relative-search
npm run benchmark:relative-search16
npm run benchmark:advanced-relative-search
npm run benchmark:search-worker
```

### Empacotamento

```bash
npm run build:unpack
npm run build:win
npm run build:mac
npm run build:linux
```

Artefatos em `dist/`. Empacotamento, assinatura e publicação exigem validação
própria; build Vite não comprova instaladores ou suporte multiplataforma.

## Fora desta versão

- Presets personalizados persistentes.
- Interface dedicada de conversão de encodings.
- Batch ROM Search.
- Font/Glyph Tools.
- Edição de ROM e patching.

Hex Viewer foi removido por decisão de produto e não está no roadmap atual.
O Character Picker é individual; não existe preenchimento sequencial.

## Créditos

**Developed by Lucas Ineth**  
© 2026 Lucas Ineth  
Built for ROM hackers & retro enthusiasts.
