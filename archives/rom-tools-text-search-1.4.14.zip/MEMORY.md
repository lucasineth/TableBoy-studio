﻿# Memória do projeto: Monkey-Moore

Informações preservadas a pedido do usuário para consultas e análises futuras.

## Alvo e identidade

- Workspace: C:/monkey-moore-v1.2.0-windows-x86_64.
- Alvo: monkey-moore.exe; 549.376 bytes; PE32+ x64; C++ nativo, Visual C++ e wxWidgets 3.3.1.
- SHA-256 analisado: 7C4F5D7B8D7F237495D431B4D6960647FD1FC370162767CA30E663F75903CDBA.
- A pasta indica v1.2.0, mas o binário contém referência textual a 1.1.0; não afirmar versão exata só pelo nome da pasta.
- Repositório indicado no executável: https://github.com/rjricken/monkey-moore.

## Conhecimento adquirido

- Ferramenta de busca relativa para localizar possíveis textos e sequências em binários/ROMs com codificação desconhecida.
- Princípio: comparar diferenças entre valores. ABCD (41 42 43 44 hexadecimal) e 80 81 82 83 preservam +1,+1,+1.
- Pré-processamento simples inclui diferença primeiro-menos-último na posição zero e diferenças atual-menos-anterior nas demais.
- Motor usa tabelas de saltos; projeto descreve Boyer-Moore. Há caminhos distintos para busca simples e busca com máscaras.
- Curingas e mistura de caixas usam máscaras e tratamento adicional. Maiúsculas/minúsculas podem ter bases distintas. Na validação ASCII mista são exigidas pelo menos três letras de uma mesma caixa; há particularidades documentadas em resource-findings.md.
- Charset personalizado define a ordem de referência dos símbolos; são comparadas diferenças entre índices dessa sequência.
- Há modos de palavra e valores numéricos, unidades de 8/16 bits e endian configurável.
- Arquivo é dividido em blocos sobrepostos: comprimento_da_palavra-1 bytes em 8 bits e 2*(comprimento_da_palavra-1) em 16 bits, além do tamanho base, limitados pelo fim do arquivo.
- Trabalhadores leem seus blocos e convertem offsets locais para offsets do arquivo. Coordenador recolhe/ordena resultados e gera prévias posteriormente.
- Caminho de 16 bits verifica deslocamentos base+0 e base+1 e pode trocar bytes de cada ushort.
- Interface oferece offset, valores, prévia e exportação editável de tabelas Thingy .tbl em ISO-8859-1, UTF-8 ou UTF-16.
- Configurações e sequências usam referências a config.xml/customseqs.xml e tinyxml2.
- Catálogo pt_BR possui cabeçalho antigo, de versão 0.5/2009; não prova a versão atual.

## Evidências para reutilizar

- analysis/RELATORIO-MONKEY-MOORE.md: relatório principal, mapa de funções e ressalvas.
- analysis/resource-findings.md: recursos, interface e validações decompiladas.
- analysis/index.json: índice dos artefatos.
- analysis/logic-decompiled.c: primeira extração de 50 funções.
- analysis/engine-decompiled.c: segunda extração de 56 funções; os conjuntos têm sobreposição.
- analysis/functions.txt: inventário de 1.991 funções identificadas, incluindo bibliotecas e thunks.
- analysis/string-xrefs.txt: strings e referências por endereço.
- analysis/MonkeyFocused.gpr e analysis/MonkeyFocused.rep: projeto Ghidra salvo.
- binary-strings-ascii.txt e binary-strings-utf16.txt: extrações iniciais; ASCII contém ruído de instruções interpretadas como texto.

## Limites e continuidade

- Foi feita análise estática; não foram executados testes pela GUI ou benchmarks do programa.
- Não foi recuperado nem revisado todo o código original. Casos extremos, deduplicação e detalhes completos de prévias permanecem parcialmente investigados.
- Correspondência é candidata; conferir contexto e outras palavras. O modelo não cobre toda tabela arbitrária, compressão ou criptografia.
- O executável original permaneceu intacto, com hash conferido ao final.
- Ferramentas REA não estavam conectadas; diagnóstico encontrou limitações de acesso/registro. As evidências de código vieram de Ghidra direto, não de registros REA Evidence.
- Ghidra instalado em C:/ghidra_12.1.3_PUBLIC e JDK em C:/jdk-25.0.4.1. Auxiliares e cópia de definições x86 foram criados em analysis para evitar modificar a instalação protegida.
- Reutilizar os relatórios e o projeto salvo antes de repetir análise; conferir hash se o alvo mudar. Não apresentar inferências ou observações estáticas como execução comprovada.
