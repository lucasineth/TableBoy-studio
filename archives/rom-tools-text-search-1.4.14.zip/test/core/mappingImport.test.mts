import assert from 'node:assert/strict'
import test from 'node:test'
import {
  extractMappingCandidates,
  prepareMappingImport,
  reviewMappingImport,
  type MappingSource,
  type ReviewedMapping
} from '../../src/core/table/MappingImport.ts'
import { RelativeSearchEngine } from '../../src/core/search/RelativeSearchEngine.ts'
import { TableEncoder } from '../../src/core/codec/TableEncoder.ts'
import { TableParser } from '../../src/core/table/TableParser.ts'
import { TableWriter } from '../../src/core/table/TableWriter.ts'
import {
  createEditorState,
  editorReducer,
  isEditorModified
} from '../../src/renderer/src/state/editorState.ts'

const source: MappingSource = { valueWidth: 1 }
const mappings = [
  { character: 'A', value: 0x81 },
  { character: 'B', value: 0x82 },
  { character: 'C', value: 0x83 }
]
const approve = (chosen = mappings, inputSource: MappingSource = source): ReviewedMapping[] =>
  extractMappingCandidates(chosen, inputSource).map((row) => ({
    ...row,
    approved: true,
    overwrite: false
  }))
const empty = { mode: '8-bit' as const, entries: [] }

test('8-bit candidates remain unconfirmed until selected and import into an empty document', () => {
  const rows = approve().map((row) => ({ ...row, approved: false }))
  assert.ok(reviewMappingImport(empty, rows, source).every((row) => row.status === 'candidate'))
  assert.throws(() => prepareMappingImport(empty, rows, source), { code: 'NO_APPROVED_MAPPINGS' })
  const plan = prepareMappingImport(empty, approve(), source)
  assert.deepEqual(plan.document.entries, [
    { key: [0x81], value: 'A' },
    { key: [0x82], value: 'B' },
    { key: [0x83], value: 'C' }
  ])
  assert.equal(plan.added, 3)
  assert.deepEqual(empty.entries, [])
})

test('imports only approved associations and preserves unrelated entries/comments', () => {
  const original = {
    mode: '8-bit' as const,
    entries: [{ key: [0x20], value: ' ', comment: 'keep' }]
  }
  const rows = approve().map((row, i) => ({ ...row, approved: i !== 1 }))
  const plan = prepareMappingImport(original, rows, source)
  assert.deepEqual(plan.document.entries[0], original.entries[0])
  assert.equal(plan.document.entries.length, 3)
  assert.ok(!plan.document.entries.some((entry) => entry.value === 'B'))
  plan.document.entries[0].key[0] = 0
  assert.equal(original.entries[0].key[0], 0x20)
})

for (const byteOrder of ['little-endian', 'big-endian'] as const) {
  test(`16-bit ${byteOrder} preserves physical bytes through import, codec and save`, () => {
    const inputSource: MappingSource = { valueWidth: 2, byteOrder }
    const rows = approve(
      [
        { character: 'あ', value: 0x8140 },
        { character: 'い', value: 0x8141 }
      ],
      inputSource
    )
    const plan = prepareMappingImport({ mode: '16-bit', entries: [] }, rows, inputSource)
    const expected =
      byteOrder === 'little-endian' ? [0x40, 0x81, 0x41, 0x81] : [0x81, 0x40, 0x81, 0x41]
    assert.deepEqual(Array.from(new TableEncoder().encode('あい', plan.document.entries)), expected)
    const text = new TableWriter().write(plan.document.entries)
    assert.deepEqual(new TableParser().parse(text).entries, plan.document.entries)
  })
}

test('wildcard candidates contain only known positions, without inferred alphabet', () => {
  const result = new RelativeSearchEngine().search(Uint8Array.from([0x81, 0x22, 0x83]), 'A?C', {
    wildcards: true
  })[0]
  const rows = approve(result.mappings)
  const plan = prepareMappingImport(empty, rows, source)
  assert.deepEqual(plan.document.entries, [
    { key: [0x81], value: 'A' },
    { key: [0x83], value: 'C' }
  ])
})

test('Value Scan has no character candidates and cannot produce an import', () => {
  assert.deepEqual(extractMappingCandidates([], source), [])
  assert.throws(() => prepareMappingImport(empty, [], source), { code: 'NO_APPROVED_MAPPINGS' })
})

test('normalizes identical reported associations but rejects inconsistent mappings', () => {
  assert.equal(extractMappingCandidates([mappings[0], mappings[0]], source).length, 1)
  assert.throws(
    () => extractMappingCandidates([mappings[0], { character: 'A', value: 0x82 }], source),
    { code: 'INVALID_MAPPING' }
  )
  assert.throws(
    () => extractMappingCandidates([mappings[0], { character: 'B', value: 0x81 }], source),
    { code: 'INVALID_MAPPING' }
  )
})

test('identical existing associations are counted without replacing their comments', () => {
  const original = {
    mode: '8-bit' as const,
    entries: [{ key: [0x81], value: 'A', comment: 'keep' }]
  }
  const plan = prepareMappingImport(original, approve([mappings[0]]), source)
  assert.equal(plan.unchanged, 1)
  assert.equal(plan.replaced, 0)
  assert.deepEqual(plan.document, original)
})

test('divergent keys require explicit replacement and preserve unrelated entries', () => {
  const original = {
    mode: '8-bit' as const,
    entries: [
      { key: [0x81], value: 'X', comment: 'keep' },
      { key: [0x20], value: ' ' }
    ]
  }
  const rows = approve([mappings[0]])
  assert.equal(reviewMappingImport(original, rows, source)[0].status, 'conflict')
  assert.throws(() => prepareMappingImport(original, rows, source), { code: 'MAPPING_CONFLICT' })
  const plan = prepareMappingImport(
    original,
    rows.map((row) => ({ ...row, overwrite: true })),
    source
  )
  assert.equal(plan.replaced, 1)
  assert.deepEqual(plan.document.entries, [
    { key: [0x81], value: 'A', comment: 'keep' },
    { key: [0x20], value: ' ' }
  ])
  assert.equal(original.entries[0].value, 'X')
})

test('duplicate keys/text in the approved selection and ambiguous existing text are rejected', () => {
  const rows = approve()
  assert.throws(() => prepareMappingImport(empty, [rows[0], rows[0]], source), {
    code: 'MAPPING_CONFLICT'
  })
  assert.throws(() => prepareMappingImport(empty, [rows[0], { ...rows[1], value: 'A' }], source), {
    code: 'MAPPING_CONFLICT'
  })
  assert.throws(
    () =>
      prepareMappingImport(
        { mode: '8-bit', entries: [{ key: [0x20], value: 'A' }] },
        [rows[0]],
        source
      ),
    { code: 'MAPPING_CONFLICT' }
  )
})

test('an invalid association prevents the entire transaction without partial mutation', () => {
  const original = { mode: '8-bit' as const, entries: [{ key: [0x20], value: ' ' }] }
  const snapshot = structuredClone(original)
  assert.throws(
    () => prepareMappingImport(original, [approve()[0], { ...approve()[1], value: '' }], source),
    { code: 'MAPPING_CONFLICT' }
  )
  assert.deepEqual(original, snapshot)
})

test('mismatched table mode and invalid width, order, value or symbol are rejected', () => {
  assert.throws(() => prepareMappingImport({ mode: '16-bit', entries: [] }, approve(), source), {
    code: 'INCOMPATIBLE_MODE'
  })
  assert.throws(() => extractMappingCandidates([{ character: 'A', value: 256 }], source), {
    code: 'INVALID_MAPPING'
  })
  assert.throws(() => extractMappingCandidates([{ character: 'AB', value: 1 }], source), {
    code: 'INVALID_MAPPING'
  })
  assert.throws(
    () =>
      extractMappingCandidates([], {
        valueWidth: 2,
        byteOrder: 'auto'
      } as unknown as MappingSource),
    { code: 'INVALID_MAPPING' }
  )
})

test('manual corrections are imported verbatim without Unicode normalization', () => {
  const rows = approve([mappings[0]]).map((row) => ({ ...row, value: 'e\u0301' }))
  const plan = prepareMappingImport(empty, rows, source)
  assert.equal(plan.document.entries[0].value, 'e\u0301')
})

test('review and cancellation change neither editor state nor original candidates', () => {
  const state = createEditorState({ mode: '8-bit', entries: [{ key: [0x20], value: ' ' }] })
  const snapshot = structuredClone(state)
  const rows = approve().map((row) => ({ ...row, approved: false }))
  const snapshotRows = structuredClone(rows)
  reviewMappingImport({ mode: state.mode, entries: state.entries }, rows, source)
  assert.deepEqual(state, snapshot)
  assert.deepEqual(rows, snapshotRows)
  assert.equal(isEditorModified(state), false)
})

test('complement is one Undo/Redo transaction, modified, preserving file metadata and save flow', () => {
  const initial = createEditorState(
    { mode: '8-bit', entries: [{ key: [0x20], value: ' ' }] },
    'existing.tbl',
    'C:/synthetic/existing.tbl'
  )
  const plan = prepareMappingImport(
    { mode: initial.mode, entries: initial.entries },
    approve(),
    source
  )
  const imported = editorReducer(initial, {
    type: 'IMPORT_DOCUMENT',
    target: 'current',
    document: plan.document
  })
  assert.equal(imported.past.length, 1)
  assert.equal(imported.filePath, initial.filePath)
  assert.ok(isEditorModified(imported))
  const undone = editorReducer(imported, { type: 'UNDO' })
  assert.deepEqual(undone.entries, initial.entries)
  const redone = editorReducer(undone, { type: 'REDO' })
  assert.deepEqual(redone.entries, plan.document.entries)
  assert.ok(isEditorModified(redone))
  const saved = editorReducer(redone, {
    type: 'MARK_SAVED',
    filePath: initial.filePath!,
    fileName: initial.fileName
  })
  assert.ok(!isEditorModified(saved))
})

test('new table is unsaved and supports one-step import Undo/Redo in its own history', () => {
  const existing = createEditorState(
    { mode: '8-bit', entries: [{ key: [0x20], value: ' ' }] },
    'existing.tbl',
    'C:/synthetic/existing.tbl'
  )
  const inputSource: MappingSource = { valueWidth: 2, byteOrder: 'little-endian' }
  const plan = prepareMappingImport(
    { mode: '16-bit', entries: [] },
    approve([{ character: 'A', value: 0x8140 }], inputSource),
    inputSource
  )
  const imported = editorReducer(existing, {
    type: 'IMPORT_DOCUMENT',
    target: 'new',
    document: plan.document
  })
  assert.equal(imported.mode, '16-bit')
  assert.equal(imported.filePath, null)
  assert.equal(imported.fileName, 'Untitled.tbl')
  assert.ok(isEditorModified(imported))
  const undone = editorReducer(imported, { type: 'UNDO' })
  assert.deepEqual(undone.entries, [])
  assert.equal(undone.mode, '16-bit')
  assert.deepEqual(editorReducer(undone, { type: 'REDO' }).entries, plan.document.entries)
})
