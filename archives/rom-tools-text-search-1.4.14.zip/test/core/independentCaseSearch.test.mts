import assert from 'node:assert/strict'
import test from 'node:test'
import { RelativeSearchEngine } from '../../src/core/search/RelativeSearchEngine.ts'
import { RelativeSearchError } from '../../src/core/search/RelativeSearchError.ts'

const engine = new RelativeSearchEngine()

test('independent case bases find mixed alphabets without changing the default relation', () => {
  const input = Uint8Array.of(0x80, 0x21, 0x22, 0x23)
  assert.equal(engine.search(input, 'Abcd').length, 0)
  const [result] = engine.search(input, 'Abcd', { independentCase: true })
  assert.deepEqual(result.mappings, [
    { character: 'A', value: 0x80 },
    { character: 'b', value: 0x21 },
    { character: 'c', value: 0x22 },
    { character: 'd', value: 0x23 }
  ])
  assert.equal(
    engine.search(Uint8Array.of(0x80, 0x21, 0x23, 0x24), 'Abcd', { independentCase: true }).length,
    0
  )
})

test('each case preserves differences, repetitions and bijection across wildcards', () => {
  const options = { independentCase: true, wildcards: true }
  assert.equal(
    engine.search(Uint8Array.of(0x80, 0x20, 0x81, 0xff, 0x82, 0x20), 'AaB?Ca', options).length,
    1
  )
  assert.equal(
    engine.search(Uint8Array.of(0x80, 0x20, 0x81, 0xff, 0x82, 0x21), 'AaB?Ca', options).length,
    0
  )
  // Distinct uppercase/lowercase symbols must still have distinct encoded values.
  assert.equal(engine.search(Uint8Array.of(0x20, 0x21, 0x22, 0x20), 'ABCa', options).length, 0)
})

test('independent case validates known letters and incompatible modes', () => {
  for (const query of ['Abc', 'ABcd', 'A??', '???']) {
    assert.throws(
      () => engine.search(new Uint8Array(20), query, { independentCase: true, wildcards: true }),
      (error) => error instanceof RelativeSearchError && error.code === 'INSUFFICIENT_CONSTRAINTS'
    )
  }
  for (const query of ['ABC!', 'ABC ', 'ABCé', 'ABC?']) {
    assert.throws(
      () => engine.search(new Uint8Array(20), query, { independentCase: true }),
      (error) => error instanceof RelativeSearchError && error.code === 'INVALID_CASE_QUERY'
    )
  }
  assert.throws(
    () =>
      engine.search(new Uint8Array(8), 'ABC', {
        independentCase: true,
        characterSequence: 'ABC'
      }),
    (error) => error instanceof RelativeSearchError && error.code === 'INCOMPATIBLE_OPTIONS'
  )
  assert.throws(
    () =>
      engine.searchValues(new Uint8Array(8), [1, 2, 3], {
        independentCase: true
      }),
    (error) => error instanceof RelativeSearchError && error.code === 'INCOMPATIBLE_OPTIONS'
  )
})

test('16-bit mixed alphabets wrap modularly and search odd offsets in both byte orders', () => {
  for (const byteOrder of ['little-endian', 'big-endian'] as const) {
    const values = [0x8000, 0xfffe, 0xffff, 0]
    const input = Uint8Array.from([
      0x55,
      ...values.flatMap((value) =>
        byteOrder === 'little-endian' ? [value & 255, value >>> 8] : [value >>> 8, value & 255]
      )
    ])
    const options = { independentCase: true, valueWidth: 2 as const, byteOrder, startOffset: 1 }
    const results = engine.search(input, 'Abcd', options)
    assert.deepEqual(
      results.map((r) => r.offset),
      [1]
    )
    assert.equal(results[0].length, 8)
    assert.equal(engine.search(input, 'Abcd', { ...options, alignment: 2 }).length, 0)
    assert.equal(engine.search(input, 'Abcd', { ...options, endOffset: 8 }).length, 0)
  }
})
