import assert from 'node:assert/strict'
import test from 'node:test'
import {
  analyzeTextCandidate,
  analyzeStringBatch,
  DEFAULT_CANDIDATE_FILTERS,
  matchesCandidateFilters
} from '../../src/core/search/TextCandidateAnalyzer.ts'
import { StringScanner } from '../../src/core/search/StringScanner.ts'
import { getCharacterEncoding } from '../../src/core/encoding/index.ts'
import { TableDecoder } from '../../src/core/codec/TableDecoder.ts'

const analyze = (text: string, encoding = 'ascii') => analyzeTextCandidate({ text, encoding })
const scanned = (text: string) =>
  analyzeStringBatch(new StringScanner().scan(new TextEncoder().encode(text), { minLength: 1 }))[0]

test('readable ASCII has deterministic, explainable high heuristic confidence', () => {
  const result = analyze('Welcome to the world!')
  assert.equal(result.confidence, 'high')
  assert.equal(result.printableRatio, 1)
  assert.equal(result.controlCharacters, 0)
  assert.ok(result.letterRatio > 0.5)
  assert.ok(result.spaceRatio > 0)
  assert.ok(result.punctuationRatio > 0)
  assert.deepEqual(result, analyze('Welcome to the world!'))
  assert.equal('score' in result, false)
  assert.equal('probability' in result, false)
})

for (const [encoding, text] of [
  ['windows-1252', 'Olá, informações úteis!'],
  ['cp437', 'CAFÉ E NOMES DE TESTE'],
  ['cp850', 'AÇÃO E OPÇÕES ÚTEIS'],
  ['shift-jis', 'こんにちは世界。カタカナ文字']
] as const) {
  test(`existing ${encoding} codec candidates are analyzed without Latin-only assumptions`, () => {
    const bytes = getCharacterEncoding(encoding).encode(text)
    const result = analyzeStringBatch(new StringScanner().scan(bytes, { encoding }))[0]
    assert.equal(result.text, text)
    assert.equal(result.analysis?.confidence, 'high')
    assert.equal(result.analysis?.characterLength, Array.from(text).length)
    assert.deepEqual(result.matchedBytes, bytes)
    if (encoding === 'shift-jis') assert.equal(result.analysis?.spaceRatio, 0)
  })
}

test('repeated runs and periodic patterns are low quality, ordinary repeated letters are not', () => {
  for (const text of ['AAAAAAAAAAAA', 'ABABABABABAB', 'XYZXYZXYZXYZ']) {
    assert.equal(analyze(text).highlyRepetitive, true)
    assert.equal(analyze(text).confidence, 'low')
  }
  assert.equal(analyze('HELLO WORLD').highlyRepetitive, false)
  assert.equal(analyze('AAAAAAAA').longestRepeatedRun, 8)
})

test('legitimate short labels deliberately receive low confidence', () => {
  for (const text of ['MENU', 'SAVE', '設定']) assert.equal(analyze(text).confidence, 'low')
  assert.match(analyze('MENU').evidence.join(' '), /legitimate menu labels/)
})

test('controls and reported decode errors remain explicit negative evidence', () => {
  const controlled = analyze('HELLO\u0000WORLD\n')
  assert.equal(controlled.controlCharacters, 2)
  assert.ok(controlled.printableRatio < 1)
  assert.equal(controlled.confidence, 'low')
  const failed = analyzeTextCandidate({
    text: 'HELLO WORLD',
    encoding: 'ascii',
    decodingErrors: ['INVALID_BYTE_SEQUENCE']
  })
  assert.equal(failed.decodingErrorCount, 1)
  assert.equal(failed.confidence, 'low')
})

test('table tokens require explicit decoder metadata and are not invented by brackets', () => {
  const text = new TableDecoder().decode(
    [1, 2],
    [
      { key: [1], value: 'HELLO WORLD ' },
      { key: [2], value: '[END]' }
    ]
  )
  const analyzed = analyzeTextCandidate({ text, encoding: 'table', knownTokens: ['[END]'] })
  assert.equal(analyzed.knownTokenCount, 1)
  assert.equal(analyzed.confidence, 'high')
  assert.equal(analyze(text).knownTokenCount, 0)
})

test('OEM box-drawing content is not promoted just because its bytes decode', () => {
  const result = analyze('┌─┬─┐│├─┤│└─┴─┘', 'cp437')
  assert.equal(result.confidence, 'low')
  assert.ok(result.symbolRatio > 0.5)
  assert.match(result.evidence.join(' '), /OEM graphic/)
  // Identical decoded text can have a different profile-specific symbol threshold.
  assert.equal(analyze('HELLO WORLD ───', 'cp437').confidence, 'medium')
  assert.equal(analyze('HELLO WORLD ───', 'shift-jis').confidence, 'high')
})

test('seeded binary data is decoded only by the existing scanner and remains deterministic', () => {
  let seed = 12345
  const bytes = Uint8Array.from({ length: 8192 }, () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0
    return seed >>> 24
  })
  const scanner = new StringScanner()
  const first = analyzeStringBatch(scanner.scan(bytes))
  assert.deepEqual(first, analyzeStringBatch(scanner.scan(bytes)))
  for (const result of first) assert.equal(result.analysis?.printableRatio, 1)
  // Readable random fragments can still be false positives: no truth label is emitted.
  assert.ok(first.length > 0)
})

test('analysis scopes truncated previews explicitly while preserving full lengths and offsets', () => {
  const source = new StringScanner().scan(new TextEncoder().encode('HELLO WORLD '.repeat(100)))[0]
  const result = analyzeStringBatch([source])[0]
  assert.equal(result.analysis?.scope, 'preview')
  assert.equal(result.analysis?.analyzedCharacters, 256)
  assert.equal(result.analysis?.characterLength, 1200)
  assert.equal(result.length, 1200)
  assert.equal(result.matchedBytes, source.matchedBytes)
  assert.equal(source.analysis, undefined)
})

test('filters are minimum-rank predicates and clearing restores unmodified originals', () => {
  const results = [
    scanned('Welcome to the world!'),
    scanned('MENU'),
    scanned('ABABABABABAB'),
    scanned('1234567890')
  ]
  const snapshot = structuredClone(results)
  const high = { ...DEFAULT_CANDIDATE_FILTERS, minimumConfidence: 'high' as const }
  assert.deepEqual(
    results.filter((result) => matchesCandidateFilters(result, high)),
    [results[0]]
  )
  assert.equal(
    results.filter((result) =>
      matchesCandidateFilters(result, { ...DEFAULT_CANDIDATE_FILTERS, minimumConfidence: 'medium' })
    ).length,
    1
  )
  assert.equal(
    matchesCandidateFilters(results[1], { ...DEFAULT_CANDIDATE_FILTERS, minimumLength: 5 }),
    false
  )
  assert.equal(
    matchesCandidateFilters(results[3], { ...DEFAULT_CANDIDATE_FILTERS, lettersOnly: true }),
    false
  )
  assert.equal(
    matchesCandidateFilters(results[2], { ...DEFAULT_CANDIDATE_FILTERS, hideRepetitive: true }),
    false
  )
  assert.equal(
    results.filter((result) => matchesCandidateFilters(result, DEFAULT_CANDIDATE_FILTERS)).length,
    4
  )
  assert.deepEqual(results, snapshot)
})

test('decode-error filters require explicit errors, absent analysis is never treated as high', () => {
  const result = scanned('HELLO WORLD')
  const failed = {
    ...result,
    analysis: analyzeTextCandidate({ ...result, decodingErrors: ['UNKNOWN_BYTE'] })
  }
  assert.equal(
    matchesCandidateFilters(failed, { ...DEFAULT_CANDIDATE_FILTERS, hideDecodingErrors: true }),
    false
  )
  const missing = { ...result, analysis: undefined }
  assert.equal(matchesCandidateFilters(missing, DEFAULT_CANDIDATE_FILTERS), true)
  assert.equal(
    matchesCandidateFilters(missing, { ...DEFAULT_CANDIDATE_FILTERS, minimumConfidence: 'high' }),
    false
  )
})

test('batch enrichment preserves order, byte references, boundaries and observes cancellation per candidate', () => {
  const source = new StringScanner().scan(new TextEncoder().encode('HELLO WORLD\0SECOND MESSAGE\0'))
  const batch = analyzeStringBatch(source, { boundaryAt: () => 'nul' })
  assert.deepEqual(
    batch.map((result) => result.offset),
    source.map((result) => result.offset)
  )
  assert.equal(batch[0].analysis?.possibleBoundary, 'nul')
  assert.equal(batch[0].matchedBytes, source[0].matchedBytes)
  assert.throws(() => analyzeStringBatch(source, { signal: { aborted: true } }), {
    code: 'SEARCH_ABORTED'
  })
  let checks = 0
  assert.throws(
    () =>
      analyzeStringBatch(source, {
        signal: {
          get aborted() {
            return ++checks > 1
          }
        }
      }),
    { code: 'SEARCH_ABORTED' }
  )
  assert.deepEqual(analyzeStringBatch([]), [])
})

test('empty text, combining marks and supplementary code points are counted explicitly without normalization', () => {
  assert.equal(analyze('').confidence, 'low')
  assert.equal(analyze('e\u0301').characterLength, 2)
  assert.equal(analyze('😀').characterLength, 1)
  assert.equal(analyze('😀').symbolRatio, 1)
})
