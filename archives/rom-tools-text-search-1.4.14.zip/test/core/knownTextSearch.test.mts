import assert from 'node:assert/strict'
import test from 'node:test'
import { KnownTextSearch } from '../../src/core/search/KnownTextSearch.ts'
import { getCharacterEncoding } from '../../src/core/encoding/index.ts'
import { writeUint16 } from '../../src/core/bytes/Endianness.ts'
import {
  extractMappingCandidates,
  prepareMappingImport
} from '../../src/core/table/MappingImport.ts'

const engine = new KnownTextSearch()
const exact = { kind: 'encoding', encoding: 'ascii' } as const
const relative = { kind: 'relative', options: { valueWidth: 1 } } as const
const ascii = (text: string) => new TextEncoder().encode(text)

test('Known-Text ASCII exact finds phrases, repeated symbols and multiple occurrences without mappings', () => {
  const bytes = ascii('HELLO WORLD\0LEVEL\0HELLO WORLD')
  const results = engine.search(bytes, ['HELLO WORLD', 'LEVEL'], exact)
  assert.deepEqual(
    results.map((r) => [r.queryIndex, r.offset, r.length]),
    [
      [0, 0, 11],
      [0, 18, 11],
      [1, 12, 5]
    ]
  )
  assert.equal(results[0].method, 'encoding')
  assert.equal(results[0].decoder, 'ascii')
  assert.deepEqual(results[0].mappings, [])
  assert.equal('confidence' in results[0], false)
  assert.deepEqual(results[0].matchedBytes, ascii('HELLO WORLD'))
})

for (const [encoding, query] of [
  ['windows-1252', 'AÇÃO €'],
  ['cp850', 'OPÇÕES'],
  ['cp437', 'CAFÉ'],
  ['shift-jis', 'こんにちは']
] as const) {
  test(`Known-Text delegates exact ${encoding} to the strict existing codec`, () => {
    const bytes = getCharacterEncoding(encoding).encode(query)
    const results = engine.search(bytes, [query], { kind: 'encoding', encoding })
    assert.equal(results[0].query, query)
    assert.equal(results[0].length, bytes.length)
  })
}

test('Known-Text loaded table delegates tokens and variable-width keys without generating mappings', () => {
  const entries = [
    { key: [0x81, 0x40], value: 'Á' },
    { key: [0xf1, 0], value: '[END]' }
  ]
  const result = engine.search(Uint8Array.from([0x81, 0x40, 0xf1, 0]), ['Á[END]'], {
    kind: 'table',
    entries,
    label: 'Synthetic table'
  })[0]
  assert.equal(result.length, 4)
  assert.equal(result.decoder, 'Synthetic table')
  assert.deepEqual(result.mappings, [])
})

test('Known-Text relative preserves repeated characters, spaces and punctuation', () => {
  for (const query of ['LEVEL', 'HELLO WORLD!', 'ABBA']) {
    const bytes = Uint8Array.from(
      Array.from(query, (character) => (character.codePointAt(0)! + 37) & 255)
    )
    const result = engine.search(bytes, [query], relative)[0]
    assert.equal(result.offset, 0)
    assert.equal(result.mappings.length, new Set(query).size)
    assert.deepEqual(result.mappingSource, { valueWidth: 1 })
    assert.equal('confidence' in result, false)
  }
})

for (const byteOrder of ['little-endian', 'big-endian'] as const) {
  test(`Known-Text relative 16-bit ${byteOrder} preserves physical bytes for Create Table`, () => {
    const bytes = new Uint8Array(6)
    for (let index = 0; index < 3; index++)
      bytes.set(writeUint16(0x8140 + index, byteOrder), index * 2)
    const result = engine.search(bytes, ['ABC'], {
      kind: 'relative',
      options: { valueWidth: 2, byteOrder }
    })[0]
    assert.equal(result.length, 6)
    const mappings = extractMappingCandidates(result.mappings, result.mappingSource!)
    assert.deepEqual(mappings[0].key, byteOrder === 'little-endian' ? [0x40, 0x81] : [0x81, 0x40])
    const plan = prepareMappingImport(
      { mode: '16-bit', entries: [] },
      mappings.map((mapping) => ({ ...mapping, approved: true, overwrite: false })),
      result.mappingSource!
    )
    assert.equal(plan.document.entries.length, 3)
  })
}

test('Known-Text wildcards and custom sequences reuse relative constraints and omit unknown mappings', () => {
  const result = engine.search(Uint8Array.from([0x81, 0x82, 0xee, 0x84, 0x85]), ['AB?DE'], {
    kind: 'relative',
    options: { valueWidth: 1, wildcards: true, characterSequence: 'ABCDE' }
  })[0]
  assert.deepEqual(
    result.mappings.map((mapping) => mapping.character),
    ['A', 'B', 'D', 'E']
  )
  assert.equal(result.length, 5)
})

test('Known-Text preserves duplicate queries as separate groups, overlapping offsets and original arrays', () => {
  const bytes = ascii('AAAA')
  const snapshot = bytes.slice()
  const queries = ['AAA', 'AAA']
  const results = engine.search(bytes, queries, exact)
  assert.deepEqual(
    results.map((r) => [r.queryIndex, r.offset]),
    [
      [0, 0],
      [0, 1],
      [1, 0],
      [1, 1]
    ]
  )
  results[0].matchedBytes[0] = 0
  assert.deepEqual(bytes, snapshot)
  assert.deepEqual(queries, ['AAA', 'AAA'])
})

test('Known-Text uses one global result limit and does not report all queries complete when capped', () => {
  const progress: number[] = []
  const results = engine.search(ascii('AAAAAA'), ['AA', 'AAA'], exact, {
    maxResults: 2,
    onProgress: (p) => progress.push(p.percentage)
  })
  assert.equal(results.length, 2)
  assert.ok(results.every((r) => r.queryIndex === 0))
  assert.ok(progress.at(-1)! < 100)
})

test('Known-Text aggregates monotonic progress and preserves bounded result batches across queries', () => {
  const bytes = ascii('HELLO\0'.repeat(260))
  const sizes: number[] = [],
    percentages: number[] = [],
    processed: number[] = []
  engine.search(bytes, ['HELLO', 'NO MATCH'], exact, {
    onResults: (batch) => sizes.push(batch.length),
    onProgress: (p) => {
      percentages.push(p.percentage)
      processed.push(p.processed)
      assert.ok(p.processed <= p.total)
      if (p.percentage === 100) assert.equal(p.processed, p.total)
    }
  })
  assert.deepEqual(sizes, [128, 128, 4])
  assert.equal(percentages.at(-1), 100)
  assert.ok(percentages.every((value, index) => index === 0 || value >= percentages[index - 1]))
  assert.ok(processed.every((value, index) => index === 0 || value >= processed[index - 1]))
})

test('Known-Text cancellation before, during and between batches remains synchronous', () => {
  assert.throws(
    () => engine.search(ascii('HELLO'), ['HELLO'], exact, { signal: { aborted: true } }),
    { code: 'SEARCH_ABORTED' }
  )
  const controller = new AbortController()
  assert.throws(
    () =>
      engine.search(ascii('HELLO\0'.repeat(300)), ['HELLO', 'WORLD'], exact, {
        signal: controller.signal,
        onResults: () => controller.abort()
      }),
    { code: 'SEARCH_ABORTED' }
  )
  const another = new AbortController()
  assert.throws(
    () =>
      engine.search(new Uint8Array(1024 * 1024), ['HELLO'], relative, {
        signal: another.signal,
        onProgress: (progress) => {
          if (progress.processed > 0) another.abort()
        }
      }),
    { code: 'SEARCH_ABORTED' }
  )
})

test('Known-Text context clips to search bounds and uses strict decoding without hiding matches', () => {
  const bytes = ascii('xxHELLOyy')
  const result = engine.search(bytes, ['HELLO'], exact, {
    startOffset: 2,
    endOffset: 7,
    contextBytes: 128
  })[0]
  assert.equal(result.context?.before.length, 0)
  assert.equal(result.context?.after.length, 0)
  assert.equal(result.context?.decodedText, 'HELLO')
  const table = {
    kind: 'table',
    label: 'Synthetic',
    entries: [{ key: [0x81, 0x40], value: 'Á' }]
  } as const
  const broken = engine.search(Uint8Array.from([0x40, 0x81, 0x40]), ['Á'], table, {
    contextBytes: 1
  })[0]
  assert.equal(broken.offset, 1)
  assert.equal(broken.context?.decodedText, undefined)
  assert.equal(broken.context?.decodeError, 'UNKNOWN_BYTE')
  assert.equal(
    engine.search(Uint8Array.from([0x81, 0x82, 0x83]), ['ABC'], relative, { contextBytes: 1 })[0]
      .context?.decodedText,
    undefined
  )
})

test('Known-Text bounded previews retain full match lengths', () => {
  const query = 'A'.repeat(512)
  const key = Array.from({ length: 32 }, (_, index) => index + 128)
  const bytes = Uint8Array.from(Array.from({ length: 512 }, () => key).flat())
  const result = engine.search(bytes, [query], {
    kind: 'table',
    entries: [{ key, value: 'A' }],
    label: 'Synthetic'
  })[0]
  assert.equal(result.length, 16384)
  assert.equal(result.matchedBytes.length, 1024)
  assert.equal(result.matchedBytesTruncated, true)
})

test('Known-Text engine preserves codec errors and rejects empty queries/invalid context', () => {
  assert.throws(() => engine.search(ascii('HELLO'), ['é'], exact), {
    code: 'UNREPRESENTABLE_CHARACTER'
  })
  assert.throws(
    () => engine.search(ascii('HELLO'), ['あ'], { kind: 'encoding', encoding: 'windows-1252' }),
    { code: 'UNREPRESENTABLE_CHARACTER' }
  )
  assert.throws(
    () => engine.search(ascii('HELLO'), ['HELLO'], { kind: 'table', entries: [], label: 'Empty' }),
    { code: 'EMPTY_TABLE' }
  )
  for (const queries of [[], ['']])
    assert.throws(() => engine.search(new Uint8Array(), queries, exact), {
      code: 'INVALID_KNOWN_QUERIES'
    })
  assert.throws(() => engine.search(ascii('HELLO'), ['HELLO'], exact, { contextBytes: 129 }), {
    code: 'INVALID_CONTEXT_BYTES'
  })
})

test('Known-Text reuses mapping conflict review without overwriting the existing table', () => {
  const result = engine.search(Uint8Array.from([0x81, 0x82, 0x83]), ['ABC'], relative)[0]
  const candidates = extractMappingCandidates(result.mappings, result.mappingSource!)
  const document = { mode: '8-bit' as const, entries: [{ key: [0x81], value: 'X' }] }
  assert.throws(
    () =>
      prepareMappingImport(
        document,
        candidates.map((entry) => ({ ...entry, approved: true, overwrite: false })),
        result.mappingSource!
      ),
    { code: 'MAPPING_CONFLICT' }
  )
  assert.equal(document.entries[0].value, 'X')
})

test('Known-Text no-match and seeded random binary fixtures do not invent results', () => {
  assert.deepEqual(engine.search(new Uint8Array(), ['HELLO'], exact), [])
  let seed = 1
  const bytes = Uint8Array.from({ length: 8192 }, () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0
    return seed >>> 24
  })
  assert.deepEqual(engine.search(bytes, ['LONG SYNTHETIC PHRASE'], exact), [])
  assert.deepEqual(
    engine.search(bytes, ['LONG SYNTHETIC PHRASE'], exact),
    engine.search(bytes, ['LONG SYNTHETIC PHRASE'], exact)
  )
})
