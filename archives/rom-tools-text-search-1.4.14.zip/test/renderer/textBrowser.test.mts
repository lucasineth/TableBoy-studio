import assert from 'node:assert/strict'
import test from 'node:test'
import {
  adaptTextResults,
  adjacentTextResult,
  DEFAULT_TEXT_BROWSER_FILTERS,
  filterTextResults,
  selectedTextPage,
  textBrowserPage,
  visibleSelection
} from '../../src/renderer/src/features/text-browser/textBrowserModel.ts'
import {
  initialRomSearchState,
  romSearchReducer,
  type RomSearchResultItem
} from '../../src/renderer/src/features/rom-search/romSearchTypes.ts'
import { analyzeTextCandidate } from '../../src/core/search/TextCandidateAnalyzer.ts'
import type { StringScannerEncoding } from '../../src/core/search/StringScannerTypes.ts'

function candidate(
  offset: number,
  text: string,
  encoding: StringScannerEncoding = 'ascii',
  length = text.length
): RomSearchResultItem {
  return {
    kind: 'strings',
    result: {
      offset,
      text,
      encoding,
      length,
      characterLength: Array.from(text).length,
      matchedBytes: new Uint8Array(length),
      previewTruncated: false,
      analysis: analyzeTextCandidate({ text, encoding })
    }
  }
}
const source = [
  candidate(40, 'Welcome to the world!'),
  candidate(10, 'MENU'),
  candidate(20, 'AÇÃO E NOMES', 'cp850'),
  candidate(30, '1234567890')
]
const items = adaptTextResults('document', 1, source)

test('Text Browser adapts only scanner results without copying text, bytes or analysis', () => {
  const mixed: RomSearchResultItem[] = [
    ...source,
    {
      kind: 'relative',
      result: { offset: 1, length: 3, matchedBytes: new Uint8Array(3), mappings: [] }
    },
    {
      kind: 'table',
      result: { offset: 2, length: 4, matchedBytes: new Uint8Array(4), matchedText: 'TEST' }
    }
  ]
  const result = adaptTextResults('document', 1, mixed)
  assert.equal(result.length, 4)
  assert.equal(result[0].source, 'string-scanner')
  assert.equal(result[0].result, source[0].result)
  assert.equal(result[0].result.matchedBytes, source[0].result.matchedBytes)
})

test('identities use document, session, offset and encoding, never array positions', () => {
  assert.equal(adaptTextResults('document', 1, [source[0]])[0].id, items[0].id)
  assert.equal(adaptTextResults('document', 1, [...source].reverse()).at(-1)?.id, items[0].id)
  assert.notEqual(adaptTextResults('other', 1, source)[0].id, items[0].id)
  assert.notEqual(adaptTextResults('document', 2, source)[0].id, items[0].id)
  assert.notEqual(
    adaptTextResults('document', 1, [candidate(40, 'TEST', 'cp850')])[0].id,
    items[0].id
  )
})

test('offset sorting supports both directions without changing originals', () => {
  assert.deepEqual(
    filterTextResults(items, DEFAULT_TEXT_BROWSER_FILTERS).map((item) => item.result.offset),
    [10, 20, 30, 40]
  )
  assert.deepEqual(
    filterTextResults(items, { ...DEFAULT_TEXT_BROWSER_FILTERS, direction: 'descending' }).map(
      (item) => item.result.offset
    ),
    [40, 30, 20, 10]
  )
  assert.deepEqual(
    items.map((item) => item.result.offset),
    [40, 10, 20, 30]
  )
})

test('length sort uses byte lengths rather than character count', () => {
  const input = adaptTextResults('doc', 0, [
    candidate(0, 'ABCD', 'shift-jis', 8),
    candidate(10, 'ABCDEFG', 'ascii', 7)
  ])
  assert.deepEqual(
    filterTextResults(input, { ...DEFAULT_TEXT_BROWSER_FILTERS, sort: 'length' }).map(
      (item) => item.result.offset
    ),
    [10, 0]
  )
})

test('confidence sorting reuses worker metadata, with unavailable last in descending order', () => {
  const missing = candidate(50, 'EXAMPLE TEXT')
  if (missing.kind === 'strings') {
    const result = { ...missing.result, analysis: undefined }
    const input = adaptTextResults('doc', 0, [...source, { kind: 'strings', result }])
    const sorted = filterTextResults(input, {
      ...DEFAULT_TEXT_BROWSER_FILTERS,
      sort: 'confidence',
      direction: 'descending'
    })
    assert.equal(sorted[0].result.analysis?.confidence, 'high')
    assert.equal(sorted.at(-1)?.result.analysis, undefined)
    assert.deepEqual(
      sorted
        .filter((item) => item.result.analysis?.confidence === 'low')
        .map((item) => item.result.offset),
      [10, 30]
    )
  }
})

test('equal sort keys use stable offset tie-breaking across batches', () => {
  const input = adaptTextResults('doc', 0, [candidate(20, 'MENU'), candidate(10, 'SAVE')])
  assert.deepEqual(
    filterTextResults(input, {
      ...DEFAULT_TEXT_BROWSER_FILTERS,
      sort: 'length',
      direction: 'descending'
    }).map((item) => item.result.offset),
    [10, 20]
  )
})

test('preview search is literal, case-insensitive and performs no normalization', () => {
  assert.equal(
    filterTextResults(items, { ...DEFAULT_TEXT_BROWSER_FILTERS, previewQuery: 'WELCOME' })[0].id,
    items[0].id
  )
  assert.equal(
    filterTextResults(items, { ...DEFAULT_TEXT_BROWSER_FILTERS, previewQuery: '.*' }).length,
    0
  )
  const composed = adaptTextResults('doc', 0, [candidate(0, 'Café')])
  assert.equal(
    filterTextResults(composed, { ...DEFAULT_TEXT_BROWSER_FILTERS, previewQuery: 'e\u0301' })
      .length,
    0
  )
})

test('encoding, confidence and length filters are reversible and preserve result references', () => {
  const snapshot = structuredClone(items)
  const view = filterTextResults(items, {
    ...DEFAULT_TEXT_BROWSER_FILTERS,
    encoding: 'cp850',
    candidate: {
      ...DEFAULT_TEXT_BROWSER_FILTERS.candidate,
      minimumConfidence: 'high',
      minimumLength: 8
    }
  })
  assert.equal(view.length, 1)
  assert.equal(view[0].result, source[2].result)
  assert.equal(filterTextResults(items, DEFAULT_TEXT_BROWSER_FILTERS).length, 4)
  assert.deepEqual(items, snapshot)
})

test('selection survives reorder and filters only while it remains in the filtered set', () => {
  const id = items[0].id
  assert.equal(
    visibleSelection(
      filterTextResults(items, { ...DEFAULT_TEXT_BROWSER_FILTERS, sort: 'confidence' }),
      id
    ),
    id
  )
  assert.equal(
    visibleSelection(
      filterTextResults(items, { ...DEFAULT_TEXT_BROWSER_FILTERS, encoding: 'cp850' }),
      id
    ),
    null
  )
  const cleared = visibleSelection([], id)
  assert.equal(visibleSelection(items, cleared), null)
})

test('previous and next navigate by stable identity and stop at boundaries', () => {
  const view = filterTextResults(items, DEFAULT_TEXT_BROWSER_FILTERS)
  assert.equal(adjacentTextResult(view, null, 1)?.id, view[0].id)
  assert.equal(adjacentTextResult(view, null, -1)?.id, view.at(-1)?.id)
  assert.equal(adjacentTextResult(view, view[0].id, -1), undefined)
  assert.equal(adjacentTextResult(view, view[0].id, 1)?.id, view[1].id)
  assert.equal(adjacentTextResult(view, view.at(-1)!.id, 1), undefined)
})

test('pagination bounds DOM work to 100 rows and supports selection on another page', () => {
  const many = adaptTextResults(
    'doc',
    0,
    Array.from({ length: 10000 }, (_, index) => candidate(index * 10, 'MENU'))
  )
  assert.equal(textBrowserPage(many, 0).items.length, 100)
  assert.equal(textBrowserPage(many, 999).page, 99)
  assert.equal(textBrowserPage(many, -1).page, 0)
  assert.equal(selectedTextPage(many, many[101].id), 1)
  assert.equal(textBrowserPage(many, 1).items[1].id, many[101].id)
})

test('empty view has one empty page and no selectable neighbor', () => {
  assert.deepEqual(textBrowserPage([], 5), { page: 0, pageCount: 1, items: [] })
  assert.equal(adjacentTextResult([], null, 1), undefined)
  assert.equal(visibleSelection([], null), null)
})

test('partial preview and analysis keep full byte offsets and lengths intact', () => {
  const item = candidate(20, 'HELLO', 'ascii', 2000)
  if (item.kind !== 'strings') throw new Error('Unexpected fixture')
  const partial = {
    ...item,
    result: {
      ...item.result,
      characterLength: 2000,
      previewTruncated: true,
      matchedBytes: new Uint8Array(5),
      analysis: analyzeTextCandidate({
        text: 'HELLO',
        encoding: 'ascii',
        characterLength: 2000,
        previewTruncated: true
      })
    }
  }
  const adapted = adaptTextResults('doc', 1, [partial])[0]
  assert.equal(adapted.result.length, 2000)
  assert.equal(adapted.result.offset, 20)
  assert.equal(adapted.result.previewTruncated, true)
  assert.equal(adapted.result.analysis?.scope, 'preview')
  assert.equal(
    filterTextResults([adapted], {
      ...DEFAULT_TEXT_BROWSER_FILTERS,
      previewQuery: 'unavailable suffix'
    }).length,
    0
  )
})

test('incremental results retain identity and selection while the session runs', () => {
  let state = romSearchReducer(initialRomSearchState, {
    type: 'DOCUMENT_OPENED',
    document: { id: 'doc', name: 'synthetic.bin', size: 1024 }
  })
  state = romSearchReducer(state, { type: 'SEARCH_STARTING' })
  state = romSearchReducer(state, { type: 'SEARCH_STARTED', jobId: 'scan' })
  state = romSearchReducer(state, { type: 'RESULTS', jobId: 'scan', results: [source[0]] })
  const first = adaptTextResults('doc', state.runId, state.results)[0]
  state = romSearchReducer(state, { type: 'RESULTS', jobId: 'scan', results: [source[1]] })
  const updated = adaptTextResults('doc', state.runId, state.results)
  assert.equal(updated[0].id, first.id)
  assert.equal(visibleSelection(updated, first.id), first.id)
})

test('cancellation preserves partial results but late events cannot append or complete', () => {
  let state = romSearchReducer(initialRomSearchState, { type: 'SEARCH_STARTING' })
  state = romSearchReducer(state, { type: 'SEARCH_STARTED', jobId: 'scan' })
  state = romSearchReducer(state, { type: 'RESULTS', jobId: 'scan', results: source })
  state = romSearchReducer(state, { type: 'CANCELLED', jobId: 'scan', resultCount: 4 })
  assert.equal(adaptTextResults('doc', state.runId, state.results).length, 4)
  assert.equal(romSearchReducer(state, { type: 'RESULTS', jobId: 'scan', results: source }), state)
  assert.equal(romSearchReducer(state, { type: 'COMPLETE', jobId: 'scan', resultCount: 8 }), state)
})

test('ROM close, replacement and new scan invalidate identities and clear old data', () => {
  let state = romSearchReducer(initialRomSearchState, {
    type: 'DOCUMENT_OPENED',
    document: { id: 'a', name: 'a.bin', size: 1024 }
  })
  state = romSearchReducer(state, { type: 'SEARCH_STARTING' })
  state = romSearchReducer(state, { type: 'SEARCH_STARTED', jobId: 'a-job' })
  state = romSearchReducer(state, { type: 'RESULTS', jobId: 'a-job', results: source })
  const old = adaptTextResults('a', state.runId, state.results)[0].id
  const reset = romSearchReducer(state, { type: 'SEARCH_STARTING' })
  assert.equal(reset.results.length, 0)
  assert.notEqual(adaptTextResults('a', reset.runId, source)[0].id, old)
  const closed = romSearchReducer(state, { type: 'DOCUMENT_CLOSED' })
  assert.equal(closed.document, null)
  assert.equal(closed.results.length, 0)
  assert.equal(
    romSearchReducer(closed, { type: 'RESULTS', jobId: 'a-job', results: source }),
    closed
  )
  const replaced = romSearchReducer(state, {
    type: 'DOCUMENT_OPENED',
    document: { id: 'b', name: 'b.bin', size: 1024 }
  })
  assert.equal(replaced.results.length, 0)
  assert.equal(
    romSearchReducer(replaced, {
      type: 'ERROR',
      jobId: 'a-job',
      error: { name: 'Error', code: 'WORKER_CRASHED', message: 'Synthetic failure' }
    }),
    replaced
  )
})

test('worker failure retains existing candidates with their original analyses for inspection', () => {
  let state = romSearchReducer(initialRomSearchState, { type: 'SEARCH_STARTING' })
  state = romSearchReducer(state, { type: 'SEARCH_STARTED', jobId: 'scan' })
  state = romSearchReducer(state, { type: 'RESULTS', jobId: 'scan', results: source })
  state = romSearchReducer(state, {
    type: 'ERROR',
    jobId: 'scan',
    error: { name: 'Error', code: 'WORKER_CRASHED', message: 'Synthetic failure' }
  })
  assert.equal(state.status, 'error')
  assert.equal(adaptTextResults('doc', state.runId, state.results)[0].result, source[0].result)
})
