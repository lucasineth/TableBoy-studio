import assert from 'node:assert/strict'
import test from 'node:test'
import {
  buildSearchRequest,
  type RomSearchFormValues
} from '../../src/renderer/src/features/rom-search/searchRequest.ts'
import {
  initialRomSearchState,
  romSearchReducer
} from '../../src/renderer/src/features/rom-search/romSearchTypes.ts'
import { adaptTextResults } from '../../src/renderer/src/features/text-browser/textBrowserModel.ts'

const form: RomSearchFormValues = {
  mode: 'known',
  query: '',
  knownQueries: 'HELLO WORLD\nLEVEL\nHELLO WORLD',
  knownMethod: 'encoding',
  knownEncoding: 'ascii',
  relativeInputMode: 'text',
  relativeCharacterMode: 'unicode',
  customSequence: '',
  wildcards: false,
  valuesInput: '',
  valueWidth: 1,
  byteOrder: 'little-endian',
  startOffset: '0',
  endOffset: '',
  alignment: '1',
  maxResults: '1000',
  contextBytes: '16',
  allowTwoSymbolQuery: false
}

test('Known-Text UI builds grouped exact queries preserving spaces and duplicates', () => {
  const built = buildSearchRequest(form, 128, [])
  assert.equal(built.ok, true)
  if (built.ok && built.request.type === 'known') {
    assert.deepEqual(built.request.queries, ['HELLO WORLD', 'LEVEL', 'HELLO WORLD'])
    assert.deepEqual(built.request.method, { kind: 'encoding', encoding: 'ascii' })
    assert.equal(built.request.options?.contextBytes, 16)
  }
})

test('Known-Text UI reuses loaded table snapshot and relative mathematical options', () => {
  const entries = [{ key: [65], value: 'A' }]
  const table = buildSearchRequest({ ...form, knownMethod: 'table' }, 128, entries, 'synthetic.tbl')
  assert.equal(table.ok, true)
  if (table.ok && table.request.type === 'known' && table.request.method.kind === 'table') {
    assert.equal(table.request.method.entries, entries)
    assert.equal(table.request.method.label, 'synthetic.tbl')
  }
  for (const byteOrder of ['little-endian', 'big-endian'] as const) {
    const relative = buildSearchRequest(
      {
        ...form,
        knownMethod: 'relative',
        valueWidth: 2,
        byteOrder,
        wildcards: true,
        relativeCharacterMode: 'custom',
        customSequence: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ '
      },
      128,
      []
    )
    assert.equal(relative.ok, true)
    if (
      relative.ok &&
      relative.request.type === 'known' &&
      relative.request.method.kind === 'relative'
    ) {
      assert.equal(relative.request.method.options.valueWidth, 2)
      assert.equal(relative.request.method.options.byteOrder, byteOrder)
      assert.equal(relative.request.method.options.wildcards, true)
    }
  }
})

test('Known-Text UI rejects empty/oversized batches, invalid bounds and missing table', () => {
  for (const values of [
    { knownQueries: '' },
    { knownQueries: 'A'.repeat(513) },
    { knownQueries: Array(17).fill('ABC').join('\n') },
    { knownMethod: 'table' as const },
    { contextBytes: '129' },
    { maxResults: '1001' },
    { startOffset: '0xZZ' },
    { alignment: '0' }
  ])
    assert.equal(buildSearchRequest({ ...form, ...values }, 128, []).ok, false)
})

test('Known-Text session metadata and results reset on ROM/new job; scanner browser ignores this origin', () => {
  let state = romSearchReducer(initialRomSearchState, {
    type: 'SEARCH_STARTING',
    knownQueries: ['ABC']
  })
  state = romSearchReducer(state, { type: 'SEARCH_STARTED', jobId: 'known-job' })
  state = romSearchReducer(state, {
    type: 'RESULTS',
    jobId: 'known-job',
    results: [
      {
        kind: 'known',
        result: {
          offset: 0,
          length: 3,
          query: 'ABC',
          queryIndex: 0,
          method: 'relative',
          decoder: 'Relative 8-bit',
          matchedBytes: new Uint8Array([129, 130, 131]),
          matchedBytesTruncated: false,
          mappings: [],
          mappingSource: { valueWidth: 1 }
        }
      }
    ]
  })
  assert.deepEqual(state.knownQueries, ['ABC'])
  assert.equal(adaptTextResults('synthetic', state.runId, state.results).length, 0)
  state = romSearchReducer(state, { type: 'CANCELLED', jobId: 'known-job', resultCount: 1 })
  assert.equal(state.results.length, 1)
  assert.equal(
    romSearchReducer(state, { type: 'RESULTS', jobId: 'known-job', results: state.results }),
    state
  )
  assert.equal(romSearchReducer(state, { type: 'SEARCH_STARTING' }).knownQueries, null)
  const closed = romSearchReducer(state, { type: 'DOCUMENT_CLOSED' })
  assert.equal(closed.knownQueries, null)
  assert.equal(closed.results.length, 0)
})
