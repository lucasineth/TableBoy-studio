import assert from 'node:assert/strict'
import test from 'node:test'
import { Worker } from 'node:worker_threads'
import { BinaryDocument } from '../../src/core/binary/index.ts'
import { SearchCoordinator } from '../../src/main/search/SearchCoordinator.ts'
import { sanitizeSearchRequest } from '../../src/main/search/SearchIpcPolicy.ts'
import type { SearchResultBatch } from '../../src/main/search/SearchProtocol.ts'

test('IPC validates independent-case types and rejects incompatible modes', () => {
  for (const options of [
    { independentCase: 'true' },
    { independentCase: true, characterSequence: 'ABC' }
  ]) {
    assert.throws(() => sanitizeSearchRequest({ type: 'relative', query: 'Abcd', options }, 10))
    assert.throws(() =>
      sanitizeSearchRequest(
        {
          type: 'known',
          queries: ['Abcd'],
          method: {
            kind: 'relative',
            options
          }
        },
        10
      )
    )
  }
  assert.throws(() =>
    sanitizeSearchRequest(
      {
        type: 'relative',
        inputMode: 'values',
        values: [1, 2, 3],
        options: { independentCase: true }
      },
      10
    )
  )
})

test('mixed-case matching survives IPC and worker for relative and known-text searches', async () => {
  const coordinator = new SearchCoordinator(
    () =>
      new Worker(new URL('../../src/main/search/searchWorker.ts', import.meta.url), {
        execArgv: ['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON', '--experimental-strip-types']
      })
  )
  await coordinator.start()
  try {
    const input = Uint8Array.of(0x80, 0x21, 0x22, 0x23, 0x90, 0x31, 0x32, 0x33)
    await coordinator.loadDocument('mixed', new BinaryDocument(input))
    for (const request of [
      { type: 'relative', query: 'Abcd', options: { independentCase: true } },
      {
        type: 'known',
        queries: ['Abcd'],
        method: {
          kind: 'relative',
          options: { independentCase: true }
        }
      }
    ]) {
      const batches: SearchResultBatch[] = []
      const job = coordinator.search('mixed', sanitizeSearchRequest(request, input.length), {
        onResults: (batch) => batches.push(batch)
      })
      assert.equal((await job.completion).resultCount, 2)
      const results = batches.flatMap((batch) =>
        batch.searchType === 'known' || batch.searchType === 'relative' ? batch.results : []
      )
      assert.deepEqual(
        results.map((result) => result.offset),
        [0, 4]
      )
      assert.equal(results[0].mappings.length, 4)
    }
  } finally {
    await coordinator.dispose()
  }
})
