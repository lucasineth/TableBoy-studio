import assert from 'node:assert/strict'
import test from 'node:test'
import { Worker } from 'node:worker_threads'
import { BinaryDocument } from '../../src/core/binary/index.ts'
import { SearchCoordinator } from '../../src/main/search/SearchCoordinator.ts'
import { sanitizeSearchRequest } from '../../src/main/search/SearchIpcPolicy.ts'
import type { SearchResultBatch } from '../../src/main/search/SearchProtocol.ts'
import { KNOWN_TEXT_LIMITS } from '../../src/core/search/KnownTextTypes.ts'

const valid = { type: 'known', queries: ['HELLO'], method: { kind: 'encoding', encoding: 'ascii' } }

test('Known-Text IPC sanitizes all three methods and never trusts functions or prototype-bearing entries', () => {
  const exact = sanitizeSearchRequest(valid, 128)
  assert.equal(exact.type, 'known')
  if (exact.type === 'known') assert.equal(exact.options?.maxResults, 1000)
  const table = sanitizeSearchRequest(
    {
      ...valid,
      method: { kind: 'table', entries: [{ key: [65], value: 'A' }], label: 'synthetic.tbl' }
    },
    128
  )
  assert.equal(table.type, 'known')
  for (const options of [
    { valueWidth: 1, wildcards: true, characterSequence: 'ABCDE' },
    { valueWidth: 2, byteOrder: 'little-endian' },
    { valueWidth: 2, byteOrder: 'big-endian' }
  ])
    assert.equal(
      sanitizeSearchRequest({ ...valid, method: { kind: 'relative', options } }, 128).type,
      'known'
    )
  for (const method of [
    null,
    { kind: 'unknown' },
    { kind: 'encoding', encoding: 'ansi' },
    { kind: 'relative', options: { valueWidth: 2 } },
    { kind: 'relative', options: { valueWidth: 1, byteOrder: 'big-endian' } },
    { kind: 'table', entries: [new Date()], label: 'bad' }
  ])
    assert.throws(() => sanitizeSearchRequest({ ...valid, method }, 128))
})

test('Known-Text IPC enforces query, aggregate, result, context, alignment and range limits', () => {
  for (const request of [
    { ...valid, queries: [] },
    { ...valid, queries: [null] },
    { ...valid, queries: [''] },
    { ...valid, queries: Array(KNOWN_TEXT_LIMITS.queries + 1).fill('HELLO') },
    { ...valid, queries: ['X'.repeat(KNOWN_TEXT_LIMITS.queryLength + 1)] },
    { ...valid, queries: Array(16).fill('X'.repeat(512)) },
    { ...valid, options: { maxResults: 1001 } },
    { ...valid, options: { contextBytes: 129 } },
    { ...valid, options: { endOffset: 129 } },
    { ...valid, options: { alignment: 0 } }
  ])
    assert.throws(() => sanitizeSearchRequest(request, 128))
})

test('Known-Text worker reuses sessions and preserves batches, origin, Unicode errors and real cancellation', async () => {
  const coordinator = new SearchCoordinator(
    () =>
      new Worker(new URL('../../src/main/search/searchWorker.ts', import.meta.url), {
        execArgv: ['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON', '--experimental-strip-types']
      })
  )
  await coordinator.start()
  try {
    const bytes = Uint8Array.from([
      ...new TextEncoder().encode('HELLO\0HELLO\0ABC\0'),
      0x81,
      0x82,
      0x83,
      0,
      0x40,
      0x81,
      0x41,
      0x81,
      0x42,
      0x81,
      0,
      0x81,
      0x40,
      0x81,
      0x41,
      0x81,
      0x42
    ])
    await coordinator.loadDocument('synthetic', new BinaryDocument(bytes))
    const batches: SearchResultBatch[] = []
    const percentages: number[] = []
    const job = coordinator.search(
      'synthetic',
      sanitizeSearchRequest(
        { ...valid, queries: ['HELLO', 'ABC'], options: { contextBytes: 2 } },
        bytes.length
      ),
      {
        onResults: (batch) => batches.push(batch),
        onProgress: (p) => percentages.push(p.percentage)
      }
    )
    assert.equal((await job.completion).resultCount, 3)
    assert.equal(percentages.at(-1), 100)
    const results = batches.flatMap((batch) => (batch.searchType === 'known' ? batch.results : []))
    assert.deepEqual(
      results.map((result) => [result.query, result.offset]),
      [
        ['HELLO', 0],
        ['HELLO', 6],
        ['ABC', 12]
      ]
    )
    assert.equal(results[0].method, 'encoding')
    for (const options of [
      { valueWidth: 1 },
      { valueWidth: 2, byteOrder: 'little-endian' },
      { valueWidth: 2, byteOrder: 'big-endian' }
    ]) {
      const found: SearchResultBatch[] = []
      const relative = coordinator.search(
        'synthetic',
        sanitizeSearchRequest(
          { ...valid, queries: ['ABC'], method: { kind: 'relative', options } },
          bytes.length
        ),
        { onResults: (batch) => found.push(batch) }
      )
      assert.ok((await relative.completion).resultCount > 0)
      assert.ok(
        found.some(
          (batch) =>
            batch.searchType === 'known' && batch.results.some((r) => r.mappings.length === 3)
        )
      )
    }
    const failed = coordinator.search('synthetic', {
      type: 'known',
      queries: ['あ'],
      method: { kind: 'encoding', encoding: 'windows-1252' }
    })
    await assert.rejects(failed.completion, (error: unknown) => {
      const envelope = (
        error as { serialized: { code: string; details: { fragment: string; position: number } } }
      ).serialized
      assert.equal(envelope.code, 'UNREPRESENTABLE_CHARACTER')
      assert.equal(envelope.details.position, 0)
      assert.equal(envelope.details.fragment, 'あ')
      return true
    })
    await coordinator.loadDocument('large', new BinaryDocument(new Uint8Array(64 * 1024 * 1024)))
    let cancel: (() => boolean) | undefined
    const long = coordinator.search(
      'large',
      {
        type: 'known',
        queries: ['HELLO', 'WORLD'],
        method: { kind: 'relative', options: { valueWidth: 1 } }
      },
      {
        onProgress: (progress) => {
          if (progress.processed > 0) cancel?.()
        }
      }
    )
    cancel = () => long.cancel()
    assert.equal((await long.completion).status, 'cancelled')
    assert.equal(await coordinator.releaseDocument('large'), true)
    assert.equal(await coordinator.releaseDocument('synthetic'), true)
  } finally {
    await coordinator.dispose()
  }
})
