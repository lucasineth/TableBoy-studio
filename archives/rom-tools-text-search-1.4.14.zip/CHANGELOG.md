# Changelog

Versões públicas e etapas internas são separadas abaixo. A numeração das etapas
não indica que cada etapa tenha tido tag, instalador ou release no GitHub.

## Não publicado — candidata 1.4.14

- Known-Text Search: composição das engines existentes para consultas exatas por
  encoding, tabela carregada e busca relativa 8/16-bit LE/BE.
- Consultas sequenciais por job, grupos identificados, progresso agregado, limites
  defensivos e cancelamento Atomics reutilizado.
- Contexto binário limitado, decode estrito opcional e mappings candidatos integrados
  ao Create Table Assistant. Nenhuma confiança estatística ou charmap é inferido.

## Etapa interna não publicada — 1.4.13

- Text Browser integrado a ROM Tools: lista paginada, inspector e navegação por
  identidade de documento/sessão/offset/encoding.
- Pesquisa literal em previews, filtros reversíveis e ordenação estável por offset,
  comprimento em bytes e confiança heurística existente.
- Reutilização de filtros/detalhes do analisador, sem novas engines, IPCs ou workers.
- Preservação da seleção visível e limpeza quando filtrada ou ao trocar de sessão.

## Etapa interna não publicada — 1.4.12

- Text Candidate Analyzer integrado ao String Scanner no worker, com métricas
  determinísticas, evidências e classificação heurística Low/Medium/High.
- Filtros de visualização reversíveis e detalhes compactos do candidato selecionado.
- Análise limitada ao preview existente, preservando offsets, bytes e comprimentos.
- Nenhuma probabilidade calibrada ou identificação automática de diálogos.

## Etapa interna não publicada — 1.4.11

- Create Table Assistant: revisão manual de mappings da Relative Search 8/16-bit
  LE/BE, confirmação individual e conflitos explícitos.
- Criação de tabela nova com proteção contra perda de alterações ou complementação
  da tabela atual, preservando entradas não relacionadas e comentários.
- Importação atômica em uma ação Undo/Redo; Save/Save As continua sendo explícito.
- Wildcards não geram associações; Value Scan permanece sem importação de caracteres.
- Proveniência da busca preservada entre navegação, conclusão e seleção de resultado.

Nenhuma tag, release ou data pública é atribuída a esta etapa. Algoritmos, codecs,
worker, IPC e ROMs permanecem inalterados.

## Etapa interna não publicada — consolidação 1.4.10

Consolida o trabalho posterior à v1.1.0. Nenhuma data de lançamento é atribuída
até a publicação autorizada da release.

### Adicionado

- TableEncoder/TableDecoder: chaves variáveis, tokens, Unicode e longest-match.
- Windows-1252, CP437, CP850 e Shift-JIS estritos; normalização explícita e LE/BE.
- BinaryDocument read-only, registry por janela e IPC binário limitado.
- Binary Search, Table Search, Relative Search 8/16-bit LE/BE e benchmarks.
- Coordinator, worker persistente, sessões, fila FIFO e cancelamento Atomics.
- Search IPC com autorização de documentos/jobs, validação e erros serializáveis.
- ROM Search UI com lotes, paginação, seleção e proteção contra eventos antigos.
- Wildcards, Custom Character Sequence e Value Scan.
- String Scanner com encodings explícitos, filtros e previews limitados.
- Checklist manual de regressão e documentação do estado atual.

### Corrigido e alterado

- Character Picker altera apenas a célula selecionada, com Undo/Redo normal.
- Exemplos/fixtures de busca usam dados sintéticos neutros.
- Package, lockfile e About alinhados à candidata 1.4.10.
- README distingue recursos do core, ações da UI e funcionalidades futuras.

### Removido

- Hex Viewer, navegação e integração “Open in Hex Viewer”, com testes exclusivos.
- Preenchimento sequencial do picker e sua implementação exclusiva.

### Etapas internas concluídas (não releases públicas)

| Etapa   | Escopo                                     |
| ------- | ------------------------------------------ |
| v1.2    | Codec de tabelas                           |
| v1.3    | Encodings, normalização e endianness       |
| v1.4.0  | Search Foundation e benchmarks             |
| v1.4.1  | BinaryDocument e lifecycle read-only       |
| v1.4.2  | Table Search                               |
| v1.4.3  | Relative Search 8-bit                      |
| v1.4.4  | Relative Search 16-bit LE/BE               |
| v1.4.5  | Search Worker e Coordinator                |
| v1.4.6  | Search IPC                                 |
| v1.4.7  | ROM Search UI                              |
| v1.4.8  | Hex Viewer, posteriormente removido        |
| v1.4.9  | Advanced Relative Search                   |
| v1.4.10 | String Scanner e consolidação da candidata |

## Releases efetivamente publicadas

### 1.1.0 — 2026-09-29

Primeira release pública, confirmada pela tag `v1.1.0` e pelo registro de
[publicação no GitHub](https://github.com/lucasineth/TableBoy-studio/releases/tag/v1.1.0).
A data corresponde à publicação, não à data de todos os commits internos.

- Editor visual de tabelas 8-bit e 16-bit com paginação.
- Unicode e tokens, catálogos PT-BR e japonês.
- Busca/validação de entradas, Undo/Redo e Drag & Drop.
- Fluxo `.tbl` e proteção contra alterações não salvas.

O MVP anterior aparece no Git como desenvolvimento inicial. Não há release
pública v1.0 confirmada na auditoria; portanto não é listada como lançamento.
