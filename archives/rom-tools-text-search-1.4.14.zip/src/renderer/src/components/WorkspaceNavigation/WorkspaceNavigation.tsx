export type WorkspaceId = 'table-editor' | 'text-search' | 'text-browser'

interface Props {
  active: WorkspaceId
  onSelect: (workspace: WorkspaceId) => void
}

export function WorkspaceNavigation({ active, onSelect }: Props): React.JSX.Element {
  return (
    <nav className="workspace-navigation" aria-label="Workspace">
      <button
        type="button"
        aria-current={active === 'table-editor' ? 'page' : undefined}
        onClick={() => onSelect('table-editor')}
      >
        Table Editor
      </button>
      <span className="workspace-navigation__divider" aria-hidden="true" />
      <span className="workspace-navigation__group">ROM Tools</span>
      <button
        type="button"
        aria-current={active === 'text-search' ? 'page' : undefined}
        onClick={() => onSelect('text-search')}
      >
        Text Search
      </button>
      <button
        type="button"
        aria-current={active === 'text-browser' ? 'page' : undefined}
        onClick={() => onSelect('text-browser')}
      >
        Text Browser
      </button>
    </nav>
  )
}
