import {
  DEFAULT_CANDIDATE_FILTERS,
  type CandidateFilters
} from '../../../../core/search/TextCandidateAnalyzer.ts'

interface Props {
  filters: CandidateFilters
  onChange: (filters: CandidateFilters) => void
  visibleCount: number
  totalCount: number
}

export function CandidateFilterControls({
  filters,
  onChange,
  visibleCount,
  totalCount
}: Props): React.JSX.Element {
  const update = <Key extends keyof CandidateFilters>(
    key: Key,
    value: CandidateFilters[Key]
  ): void => onChange({ ...filters, [key]: value })
  return (
    <fieldset className="candidate-filters">
      <legend>Candidate filters (view only)</legend>
      <label>
        Minimum confidence
        <select
          value={filters.minimumConfidence}
          onChange={(event) =>
            update('minimumConfidence', event.target.value as CandidateFilters['minimumConfidence'])
          }
        >
          <option value="any">Any</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </label>
      <label>
        Minimum characters
        <input
          type="number"
          min={0}
          step={1}
          value={filters.minimumLength}
          onChange={(event) => {
            const value = event.target.value
            if (/^\d+$/.test(value) && Number.isSafeInteger(Number(value)))
              update('minimumLength', Number(value))
            else if (value === '') update('minimumLength', 0)
          }}
        />
      </label>
      <label>
        <input
          type="checkbox"
          checked={filters.lettersOnly}
          onChange={(event) => update('lettersOnly', event.target.checked)}
        />
        With letters only
      </label>
      <label>
        <input
          type="checkbox"
          checked={filters.hideRepetitive}
          onChange={(event) => update('hideRepetitive', event.target.checked)}
        />
        Hide highly repetitive
      </label>
      <label>
        <input
          type="checkbox"
          checked={filters.hideDecodingErrors}
          onChange={(event) => update('hideDecodingErrors', event.target.checked)}
        />
        Hide decoding errors
      </label>
      <button
        type="button"
        className="secondary-button"
        onClick={() => onChange(DEFAULT_CANDIDATE_FILTERS)}
      >
        Clear filters
      </button>
      <small role="status">
        Showing {visibleCount} of {totalCount} original results. Confidence is heuristic, not a
        probability.
      </small>
    </fieldset>
  )
}
