import { useState } from 'react'
import type { KnownTextSearchResult } from '../../../../core/search/KnownTextTypes.ts'
import type { MappingSource } from '../../../../core/table/MappingImport.ts'
import type { RelativeSearchResult } from '../../../../core/search/RelativeSearchTypes.ts'
import { formatHexBytes, formatHexOffset, formatMapping } from './formatting.ts'

interface Props {
  results: readonly KnownTextSearchResult[]
  queries: readonly string[]
  documentSize: number
  searching: boolean
  onCreateTable: (result: RelativeSearchResult, source: MappingSource) => void
}

export function KnownTextResults({
  results,
  queries,
  documentSize,
  searching,
  onCreateTable
}: Props): React.JSX.Element {
  const [group, setGroup] = useState('all')
  const [page, setPage] = useState(0)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const id = (result: KnownTextSearchResult): string => `${result.queryIndex}:${result.offset}`
  const filtered = results.filter(
    (result) => group === 'all' || result.queryIndex === Number(group)
  )
  const pageCount = Math.max(1, Math.ceil(filtered.length / 100))
  const safePage = Math.min(page, pageCount - 1)
  const selected = filtered.find((result) => id(result) === selectedId)
  return (
    <>
      <label className="known-query-filter">
        Query group
        <select
          value={group}
          onChange={(event) => {
            setGroup(event.target.value)
            setPage(0)
            setSelectedId(null)
          }}
        >
          <option value="all">All queries ({results.length} received)</option>
          {queries.map((query, index) => (
            <option key={`${index}:${query}`} value={index}>
              {index + 1}. {query} ({results.filter((result) => result.queryIndex === index).length}
              {' received)'}
            </option>
          ))}
        </select>
      </label>
      <small className="known-query-note">
        Counts are received matches. A result cap or error may leave later queries unsearched.
      </small>
      <div className="rom-search-results__content">
        <div className="rom-search-result-list" role="listbox" aria-label="Known-text matches">
          {filtered.slice(safePage * 100, (safePage + 1) * 100).map((result) => (
            <button
              type="button"
              role="option"
              aria-selected={selectedId === id(result)}
              key={id(result)}
              className={`rom-search-result${selectedId === id(result) ? ' rom-search-result--selected' : ''}`}
              onClick={() => setSelectedId(id(result))}
            >
              <span className="rom-search-result__offset">
                {formatHexOffset(result.offset, documentSize)}
              </span>
              <span className="rom-search-result__primary">
                {result.queryIndex + 1}. {result.query}
              </span>
              <span className="rom-search-result__bytes">
                {formatHexBytes(result.matchedBytes)}
                {result.matchedBytesTruncated ? ' … (Preview)' : ''}
              </span>
              <span className="rom-search-result__context">
                {result.method} · {result.decoder} · {result.length} bytes · Candidate match only
              </span>
            </button>
          ))}
          {filtered.length === 0 ? (
            <p className="text-browser-empty">
              {searching
                ? 'Searching queries sequentially…'
                : 'No matches received for this query group.'}
            </p>
          ) : null}
        </div>
        <div className="rom-search-pagination">
          <button type="button" disabled={safePage === 0} onClick={() => setPage(safePage - 1)}>
            Previous
          </button>
          <span>
            Page {safePage + 1} of {pageCount}
          </span>
          <button
            type="button"
            disabled={safePage + 1 >= pageCount}
            onClick={() => setPage(safePage + 1)}
          >
            Next
          </button>
        </div>
      </div>
      {selected ? (
        <section className="candidate-details" aria-label="Known-text inspector">
          <strong>
            {selected.query} · {selected.decoder}
          </strong>
          <p>
            Offset {formatHexOffset(selected.offset, documentSize)} · {selected.length} bytes ·{' '}
            {selected.method}
          </p>
          {selected.mappings.length > 0 ? (
            <>
              <p>
                Candidate mappings (not confirmed):{' '}
                {formatMapping(selected.mappings, selected.mappingSource?.valueWidth ?? 1)}
              </p>
              <button
                type="button"
                className="secondary-button"
                disabled={searching}
                onClick={() => {
                  if (selected.mappingSource)
                    onCreateTable(
                      {
                        offset: selected.offset,
                        length: selected.length,
                        matchedBytes: selected.matchedBytes,
                        mappings: selected.mappings
                      },
                      selected.mappingSource
                    )
                }}
              >
                Create Table
              </button>
            </>
          ) : (
            <p>No character mappings were produced by this method.</p>
          )}
          {selected.context ? (
            <>
              <p>Before: {formatHexBytes(selected.context.before) || '—'}</p>
              <p>After: {formatHexBytes(selected.context.after) || '—'}</p>
              <p>
                Context preview:{' '}
                {selected.context.decodedText ??
                  (selected.context.decodeError
                    ? `Not decodable (${selected.context.decodeError}). Raw bytes remain available.`
                    : 'No applicable decoder for unknown relative mapping.')}
              </p>
              <small>
                Surrounding bytes may belong to unrelated data. Arbitrary multibyte boundaries may
                not decode.
              </small>
            </>
          ) : (
            <p>No context requested.</p>
          )}
        </section>
      ) : null}
    </>
  )
}
