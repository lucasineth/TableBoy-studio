import { useEffect } from 'react'

import type { TableEntry } from '../../../../core/table/index.ts'
import type { SerializedSearchError } from '../../../../shared/searchApi.ts'
import { formatFileSize, formatHexOffset } from './formatting.ts'
import { SearchControls } from './SearchControls.tsx'
import { CandidateResults } from './CandidateResults.tsx'
import type { RomSearchRequest } from './searchRequest.ts'
import type { RomSearchState } from './romSearchTypes.ts'
import type { RelativeSearchResult } from '../../../../core/search/RelativeSearchTypes.ts'
import type { MappingSource } from '../../../../core/table/MappingImport.ts'
import { TextBrowserPanel } from '../text-browser/TextBrowserPanel.tsx'
import { KnownTextResults } from './KnownTextResults.tsx'

interface RomSearchPanelProps {
  active: boolean
  tool: 'search' | 'browser'
  state: RomSearchState
  tableEntries: readonly TableEntry[]
  tableLabel?: string
  onOpenDocument: () => void
  onCloseDocument: () => void
  onSearch: (request: RomSearchRequest) => void
  onCancel: () => void
  onSelectResult: (offset: number) => void
  onCreateTable: (result: RelativeSearchResult, source: MappingSource) => void
}

export function RomSearchPanel({
  active,
  tool,
  state,
  tableEntries,
  tableLabel,
  onOpenDocument,
  onCloseDocument,
  onSearch,
  onCancel,
  onSelectResult,
  onCreateTable
}: RomSearchPanelProps): React.JSX.Element {
  const relativeValueWidth = state.relativeSource?.valueWidth ?? 1
  const selectedResult = state.results.find(
    (item) => item.result.offset === state.selectedResultOffset
  )

  useEffect(() => {
    const cancelOnEscape = (event: KeyboardEvent): void => {
      if (active && event.key === 'Escape' && state.status === 'searching') {
        event.preventDefault()
        onCancel()
      }
    }
    window.addEventListener('keydown', cancelOnEscape)
    return () => window.removeEventListener('keydown', cancelOnEscape)
  }, [active, onCancel, state.status])

  const handleSearch = (request: RomSearchRequest): void => {
    onSearch(request)
  }

  return (
    <main className="workspace-view rom-search-workspace" hidden={!active}>
      <header className={`rom-tools-header${state.document ? ' rom-document-bar' : ''}`}>
        <div>
          <h1>{tool === 'search' ? 'Text Search' : 'Text Browser'}</h1>
        </div>
        {state.document ? (
          <div className="rom-document-identity">
            <strong title={state.document.name}>{state.document.name}</strong>
            <small>{formatFileSize(state.document.size)}</small>
          </div>
        ) : null}
        <span className="read-only-badge">Read-only</span>
        {state.document ? (
          <div className="rom-tools-header__actions">
            <button type="button" className="secondary-button" onClick={onOpenDocument}>
              Replace file…
            </button>
            <button type="button" className="secondary-button" onClick={onCloseDocument}>
              Close ROM
            </button>
          </div>
        ) : null}
      </header>

      {!state.document ? (
        <section className="rom-empty-state" aria-labelledby="rom-empty-title">
          <h2 id="rom-empty-title">Open a ROM or binary file.</h2>
          <p>Inspect and search text candidates without changing the original file.</p>
          {state.error ? <SearchErrorMessage error={state.error} /> : null}
          <button type="button" className="primary-button" onClick={onOpenDocument}>
            Open ROM or Binary…
          </button>
        </section>
      ) : (
        <>
          {state.document.size === 0 ? (
            <section className="rom-empty-state rom-empty-state--compact">
              <h2>The binary document is empty</h2>
              <p>There are no bytes available to search.</p>
            </section>
          ) : (
            <>
              <div className="rom-search-layout rom-tool-view" hidden={tool !== 'search'}>
                <SearchControls
                  documentSize={state.document.size}
                  tableEntries={tableEntries}
                  tableLabel={tableLabel}
                  status={state.status}
                  onSearch={handleSearch}
                  onCancel={onCancel}
                />
                <section className="rom-search-results" aria-label="Search results">
                  <SearchSummary state={state} />
                  {state.error ? <SearchErrorMessage error={state.error} /> : null}
                  {state.knownQueries ? (
                    <KnownTextResults
                      key={state.runId}
                      queries={state.knownQueries}
                      results={state.results.flatMap((item) =>
                        item.kind === 'known' ? [item.result] : []
                      )}
                      documentSize={state.document.size}
                      searching={state.status === 'searching'}
                      onCreateTable={onCreateTable}
                    />
                  ) : (
                    <CandidateResults
                      key={state.runId}
                      results={state.results}
                      documentSize={state.document.size}
                      relativeValueWidth={relativeValueWidth}
                      selectedOffset={state.selectedResultOffset}
                      onSelect={onSelectResult}
                    />
                  )}
                  {state.selectedResultOffset !== null ? (
                    <div className="selected-search-result" role="status">
                      <span>
                        Selected offset:{' '}
                        {formatHexOffset(state.selectedResultOffset, state.document.size)}
                      </span>
                      {selectedResult?.kind === 'relative' && state.relativeSource ? (
                        <>
                          <button
                            type="button"
                            className="secondary-button"
                            disabled={
                              selectedResult.result.mappings.length === 0 ||
                              state.status === 'searching'
                            }
                            onClick={() =>
                              onCreateTable(selectedResult.result, state.relativeSource!)
                            }
                          >
                            Create Table
                          </button>
                          {selectedResult.result.mappings.length === 0 ? (
                            <small>Value Scan has no character mappings to import.</small>
                          ) : null}
                        </>
                      ) : null}
                    </div>
                  ) : null}
                </section>
              </div>
              <section
                className="rom-search-results rom-tool-view"
                hidden={tool !== 'browser'}
                aria-label="Text Browser"
              >
                <SearchSummary state={state} />
                {state.error ? <SearchErrorMessage error={state.error} /> : null}
                <TextBrowserPanel
                  key={`${state.document.id}:${state.runId}`}
                  state={state}
                  onCancel={onCancel}
                />
              </section>
            </>
          )}
        </>
      )}
    </main>
  )
}

function SearchSummary({ state }: { state: RomSearchState }): React.JSX.Element {
  const visibleCount = state.results.length
  const reportedCount =
    state.status === 'completed' || state.status === 'cancelled' ? state.resultCount : visibleCount
  return (
    <div className="rom-search-summary">
      <div>
        <strong>{statusLabel(state.status)}</strong>
        <span>{reportedCount} results</span>
      </div>
      <div className="rom-search-progress">
        <progress
          max={100}
          value={state.progress?.percentage ?? 0}
          aria-label="Search progress"
          aria-valuetext={`${formatPercentage(state.progress?.percentage ?? 0)} percent`}
        />
        <span>{formatPercentage(state.progress?.percentage ?? 0)}%</span>
      </div>
    </div>
  )
}

function SearchErrorMessage({ error }: { error: SerializedSearchError }): React.JSX.Element {
  const details = error.details
  return (
    <div className="rom-search-error" role="alert">
      <strong>{friendlyError(error.code, error.message)}</strong>
      {typeof details?.fragment === 'string' ? <span>Fragment: {details.fragment}</span> : null}
      {typeof details?.position === 'number' ? <span>Position: {details.position}</span> : null}
      {typeof details?.reason === 'string' ? <span>{details.reason}</span> : null}
    </div>
  )
}

function friendlyError(code: string | undefined, fallback: string): string {
  switch (code) {
    case 'UNMAPPED_TEXT':
      return 'Some characters are not present in the loaded table.'
    case 'QUERY_TOO_SHORT':
      return 'Relative Search requires at least 3 symbols.'
    case 'SEARCH_QUEUE_FULL':
      return 'The search queue is full. Try again after the current search finishes.'
    case 'DOCUMENT_NOT_FOUND':
      return 'The binary document is no longer available.'
    case 'INSUFFICIENT_CONSTRAINTS':
      return 'Use at least two known positions in a wildcard search.'
    case 'SYMBOL_NOT_IN_SEQUENCE':
      return 'The query contains a symbol missing from the custom sequence.'
    case 'DUPLICATE_SEQUENCE_SYMBOL':
      return 'The custom character sequence contains duplicate symbols.'
    case 'EMPTY_CHARACTER_SEQUENCE':
      return 'Enter a custom character sequence.'
    case 'INVALID_RELATIVE_VALUE':
      return 'One or more Value Scan numbers are outside the selected width.'
    default:
      return fallback
  }
}

function statusLabel(status: RomSearchState['status']): string {
  return status.charAt(0).toUpperCase() + status.slice(1)
}

function formatPercentage(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(1)
}
