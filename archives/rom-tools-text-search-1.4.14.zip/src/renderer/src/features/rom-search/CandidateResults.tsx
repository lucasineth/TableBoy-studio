import { useMemo, useState } from 'react'
import {
  DEFAULT_CANDIDATE_FILTERS,
  matchesCandidateFilters,
  type CandidateFilters,
  type TextCandidateAnalysis
} from '../../../../core/search/TextCandidateAnalyzer.ts'
import { SearchResults } from './SearchResults.tsx'
import { CandidateFilterControls } from './CandidateFilterControls.tsx'
import type { RomSearchResultItem } from './romSearchTypes.ts'

interface Props {
  results: readonly RomSearchResultItem[]
  documentSize: number
  relativeValueWidth: 1 | 2
  selectedOffset: number | null
  onSelect: (offset: number) => void
}

export function CandidateResults(props: Props): React.JSX.Element {
  const [filters, setFilters] = useState<CandidateFilters>(DEFAULT_CANDIDATE_FILTERS)
  const hasStrings = props.results.some((item) => item.kind === 'strings')
  const filtered = useMemo(
    () =>
      props.results.filter(
        (item) => item.kind !== 'strings' || matchesCandidateFilters(item.result, filters)
      ),
    [props.results, filters]
  )
  const selected = filtered.find((item) => item.result.offset === props.selectedOffset)

  return (
    <>
      {hasStrings ? (
        <CandidateFilterControls
          filters={filters}
          onChange={setFilters}
          visibleCount={filtered.length}
          totalCount={props.results.length}
        />
      ) : null}
      {hasStrings && filtered.length === 0 ? (
        <div className="rom-search-results__empty">
          No candidates match these filters. Clear filters to restore the original results.
        </div>
      ) : (
        <SearchResults {...props} results={filtered} />
      )}
      {selected?.kind === 'strings' && selected.result.analysis ? (
        <CandidateDetails analysis={selected.result.analysis} />
      ) : null}
    </>
  )
}

export function CandidateDetails({
  analysis
}: {
  analysis: TextCandidateAnalysis
}): React.JSX.Element {
  const percentage = (ratio: number): string => `${(ratio * 100).toFixed(1)}%`
  return (
    <section className="candidate-details" aria-label="Selected candidate analysis">
      <h3>{analysis.confidence} confidence — heuristic evidence</h3>
      <p>
        {analysis.scope === 'preview' ? 'Partial preview analysis' : 'Complete candidate analysis'}{' '}
        · {analysis.analyzedCharacters} code points inspected · {analysis.characterLength} total
        characters
      </p>
      <dl>
        <dt>Printable</dt>
        <dd>{percentage(analysis.printableRatio)}</dd>
        <dt>Controls</dt>
        <dd>{analysis.controlCharacters}</dd>
        <dt>Diversity</dt>
        <dd>{percentage(analysis.diversity)}</dd>
        <dt>Letters / marks</dt>
        <dd>{percentage(analysis.letterRatio)}</dd>
        <dt>Numbers</dt>
        <dd>{percentage(analysis.numberRatio)}</dd>
        <dt>Punctuation</dt>
        <dd>{percentage(analysis.punctuationRatio)}</dd>
        <dt>Symbols</dt>
        <dd>{percentage(analysis.symbolRatio)}</dd>
        <dt>Spaces</dt>
        <dd>{percentage(analysis.spaceRatio)}</dd>
        <dt>Longest repeated run</dt>
        <dd>{analysis.longestRepeatedRun}</dd>
        <dt>Known tokens</dt>
        <dd>{analysis.knownTokenCount}</dd>
        <dt>Decoding errors</dt>
        <dd>{analysis.decodingErrorCount}</dd>
      </dl>
      <ul>
        {analysis.evidence.map((evidence) => (
          <li key={evidence}>{evidence}</li>
        ))}
      </ul>
      <small>
        Category ratios describe analyzed characters, excluding explicitly known tokens. Strict
        String Scanner ends runs at controls or decoding failures; it does not return those failures
        as candidates.
      </small>
    </section>
  )
}
