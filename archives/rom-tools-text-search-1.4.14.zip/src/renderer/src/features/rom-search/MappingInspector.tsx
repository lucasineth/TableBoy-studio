import { useEffect, useMemo, useRef, useState } from 'react'
import {
  extractMappingCandidates,
  prepareMappingImport,
  reviewMappingImport,
  type MappingSource,
  type ReviewedMapping
} from '../../../../core/table/MappingImport.ts'
import type { TableDocument } from '../../../../core/table/TableDocument.ts'
import type { RelativeSearchResult } from '../../../../core/search/RelativeSearchTypes.ts'
import { formatHexBytes, formatHexOffset } from './formatting.ts'

interface MappingInspectorProps {
  result: RelativeSearchResult
  source: MappingSource
  document: TableDocument
  fileName: string
  onClose: () => void
  onApply: (rows: readonly ReviewedMapping[], target: 'new' | 'current') => Promise<boolean>
}

export function MappingInspector({
  result,
  source,
  document,
  fileName,
  onClose,
  onApply
}: MappingInspectorProps): React.JSX.Element {
  const [rows, setRows] = useState<ReviewedMapping[]>(() =>
    extractMappingCandidates(result.mappings, source).map((candidate) => ({
      ...candidate,
      approved: false,
      overwrite: false
    }))
  )
  const mode = source.valueWidth === 1 ? '8-bit' : '16-bit'
  const [target, setTarget] = useState<'new' | 'current'>(
    document.mode === mode ? 'current' : 'new'
  )
  const [finalReview, setFinalReview] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const panelRef = useRef<HTMLElement>(null)
  const effectiveDocument = useMemo<TableDocument>(
    () => (target === 'new' ? { mode, entries: [] } : document),
    [document, mode, target]
  )
  const review = useMemo(
    () => reviewMappingImport(effectiveDocument, rows, source),
    [effectiveDocument, rows, source]
  )
  const plan = useMemo(() => {
    try {
      return prepareMappingImport(effectiveDocument, rows, source)
    } catch {
      return null
    }
  }, [effectiveDocument, rows, source])

  useEffect(() => {
    const previousFocus = window.document.activeElement as HTMLElement | null
    panelRef.current?.focus()
    return () => previousFocus?.focus()
  }, [])

  const update = (index: number, changes: Partial<ReviewedMapping>): void => {
    setRows((current) => current.map((row, i) => (i === index ? { ...row, ...changes } : row)))
    setFinalReview(false)
    setError(null)
  }

  const apply = async (): Promise<void> => {
    setBusy(true)
    setError(null)
    try {
      if (await onApply(rows, target)) onClose()
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : 'Could not import the mappings.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="dialog-backdrop">
      <section
        className="app-dialog mapping-inspector"
        role="dialog"
        aria-modal="true"
        aria-labelledby="mapping-inspector-title"
        tabIndex={-1}
        ref={panelRef}
        onKeyDown={(event) => {
          if (event.key === 'Escape' && !busy) {
            event.stopPropagation()
            onClose()
          }
          if (event.key === 'Tab') {
            const controls = panelRef.current?.querySelectorAll<HTMLElement>(
              'button:not(:disabled), input:not(:disabled), select:not(:disabled)'
            )
            const first = controls?.[0]
            const last = controls?.[controls.length - 1]
            if (
              event.shiftKey &&
              (window.document.activeElement === first ||
                window.document.activeElement === panelRef.current)
            ) {
              event.preventDefault()
              last?.focus()
            } else if (!event.shiftKey && window.document.activeElement === last) {
              event.preventDefault()
              first?.focus()
            }
          }
        }}
      >
        <header className="app-dialog__header">
          <h2 id="mapping-inspector-title">Create Table — Mapping Inspector</h2>
          <button
            type="button"
            disabled={busy}
            aria-label="Close mapping inspector"
            onClick={onClose}
          >
            ×
          </button>
        </header>
        <div className="mapping-inspector__body">
          <p>
            Candidate at {formatHexOffset(result.offset)} · {mode}
            {source.valueWidth === 2 ? ` · ${source.byteOrder}` : ''}
          </p>
          <p className="mapping-inspector__bytes">
            Matched bytes: {formatHexBytes(result.matchedBytes)}
          </p>
          <p>Approve only associations you have reviewed. No missing symbols will be inferred.</p>
          <label className="rom-search-field">
            <span>Destination</span>
            <select
              value={target}
              disabled={busy || finalReview}
              onChange={(event) => {
                setTarget(event.target.value as 'new' | 'current')
                setError(null)
              }}
            >
              <option value="current">
                Complement {fileName} ({document.mode})
              </option>
              <option value="new">New unsaved {mode} table</option>
            </select>
          </label>
          {source.valueWidth === 2 && source.byteOrder === 'little-endian' ? (
            <p>Keys below preserve physical LE bytes. A value 8140 becomes .tbl key 4081.</p>
          ) : null}
          <div className="mapping-inspector__table-wrap">
            <table className="mapping-inspector__table">
              <thead>
                <tr>
                  <th>Approve</th>
                  <th>.tbl key</th>
                  <th>Character / text</th>
                  <th>Status</th>
                  <th>Existing / resolution</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, index) => {
                  const rowReview = review[index]
                  const key = formatHexBytes(Uint8Array.from(row.key)).replaceAll(' ', '')
                  const divergent =
                    rowReview.existingValue !== undefined && rowReview.existingValue !== row.value
                  return (
                    <tr key={key}>
                      <td>
                        <input
                          type="checkbox"
                          aria-label={`Approve ${key}`}
                          checked={row.approved}
                          disabled={busy || finalReview}
                          onChange={(event) =>
                            update(index, { approved: event.target.checked, overwrite: false })
                          }
                        />
                      </td>
                      <td>
                        <code>{key}</code>
                      </td>
                      <td>
                        <input
                          aria-label={`Character for ${key}`}
                          value={row.value}
                          disabled={busy || finalReview}
                          onChange={(event) =>
                            update(index, {
                              value: event.target.value,
                              approved: false,
                              overwrite: false
                            })
                          }
                        />
                      </td>
                      <td>
                        <span className={`mapping-status mapping-status--${rowReview.status}`}>
                          {rowReview.status === 'conflict'
                            ? 'Conflict'
                            : row.approved
                              ? 'Confirmed'
                              : 'Candidate'}
                        </span>
                      </td>
                      <td>
                        {rowReview.existingValue !== undefined ? (
                          <span>
                            Existing: {JSON.stringify(rowReview.existingValue)}
                            {!divergent ? ' (identical)' : ''}
                          </span>
                        ) : null}
                        {divergent ? (
                          <label className="rom-search-check">
                            <input
                              type="checkbox"
                              checked={row.overwrite}
                              disabled={!row.approved || busy || finalReview}
                              aria-label={`Replace existing ${key}`}
                              onChange={(event) =>
                                update(index, { overwrite: event.target.checked })
                              }
                            />
                            Replace existing entry
                          </label>
                        ) : null}
                        {rowReview.error ? (
                          <small className="mapping-inspector__error">{rowReview.error}</small>
                        ) : null}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          {finalReview && plan ? (
            <div role="status" className="mapping-inspector__summary">
              <strong>Final review: {target === 'new' ? 'new unsaved table' : fileName}</strong>
              <p>
                {plan.added} added · {plan.replaced} replaced · {plan.unchanged} identical
              </p>
              <p>
                Only checked associations will be applied as one Undo/Redo transaction. Nothing will
                be saved automatically.
              </p>
            </div>
          ) : null}
          {error ? (
            <p role="alert" className="mapping-inspector__error">
              {error}
            </p>
          ) : null}
        </div>
        <footer className="app-dialog__footer">
          <button type="button" disabled={busy} onClick={onClose}>
            Cancel
          </button>
          {finalReview ? (
            <>
              <button type="button" disabled={busy} onClick={() => setFinalReview(false)}>
                Back to mappings
              </button>
              <button type="button" disabled={!plan || busy} onClick={() => void apply()}>
                {busy ? 'Applying…' : 'Apply approved mappings'}
              </button>
            </>
          ) : (
            <button type="button" disabled={!plan} onClick={() => setFinalReview(true)}>
              Review changes
            </button>
          )}
        </footer>
      </section>
    </div>
  )
}
