import type {
  StringScannerResult,
  StringScannerEncoding
} from '../../../../core/search/StringScannerTypes.ts'
import {
  DEFAULT_CANDIDATE_FILTERS,
  matchesCandidateFilters,
  type CandidateFilters
} from '../../../../core/search/TextCandidateAnalyzer.ts'
import type { RomSearchResultItem } from '../rom-search/romSearchTypes.ts'

export interface TextBrowserItem {
  readonly id: string
  readonly source: 'string-scanner'
  readonly result: StringScannerResult
}

export interface TextBrowserFilters {
  readonly candidate: CandidateFilters
  readonly encoding: 'any' | StringScannerEncoding
  readonly previewQuery: string
  readonly sort: 'offset' | 'length' | 'confidence'
  readonly direction: 'ascending' | 'descending'
}

export const DEFAULT_TEXT_BROWSER_FILTERS: TextBrowserFilters = Object.freeze({
  candidate: DEFAULT_CANDIDATE_FILTERS,
  encoding: 'any',
  previewQuery: '',
  sort: 'offset',
  direction: 'ascending'
})
export const TEXT_BROWSER_PAGE_SIZE = 100

/** Metadata-only adapter; text and byte buffers retain their existing references. */
export function adaptTextResults(
  documentId: string,
  runId: number,
  results: readonly RomSearchResultItem[]
): TextBrowserItem[] {
  return results.flatMap((item) =>
    item.kind === 'strings'
      ? [
          {
            id: JSON.stringify([documentId, runId, item.result.offset, item.result.encoding]),
            source: 'string-scanner' as const,
            result: item.result
          }
        ]
      : []
  )
}

export function filterTextResults(
  items: readonly TextBrowserItem[],
  filters: TextBrowserFilters
): TextBrowserItem[] {
  // Literal, case-insensitive preview search only. No normalization, regex or ROM reads.
  const query = filters.previewQuery.toLowerCase()
  const ranks = { low: 0, medium: 1, high: 2 }
  const view = items.filter(
    (item) =>
      (filters.encoding === 'any' || item.result.encoding === filters.encoding) &&
      item.result.text.toLowerCase().includes(query) &&
      matchesCandidateFilters(item.result, filters.candidate)
  )
  return view.sort((a, b) => {
    const difference =
      filters.sort === 'length'
        ? a.result.length - b.result.length
        : filters.sort === 'confidence'
          ? (a.result.analysis ? ranks[a.result.analysis.confidence] : -1) -
            (b.result.analysis ? ranks[b.result.analysis.confidence] : -1)
          : a.result.offset - b.result.offset
    if (difference !== 0) return filters.direction === 'ascending' ? difference : -difference
    // Offset tie-break is deterministic across incremental batches; sort itself is stable.
    return a.result.offset - b.result.offset
  })
}

export function visibleSelection(
  items: readonly TextBrowserItem[],
  id: string | null
): string | null {
  return id !== null && items.some((item) => item.id === id) ? id : null
}

export function adjacentTextResult(
  items: readonly TextBrowserItem[],
  id: string | null,
  step: -1 | 1
): TextBrowserItem | undefined {
  const index = items.findIndex((item) => item.id === id)
  if (index < 0) return step === 1 ? items[0] : items.at(-1)
  return items[index + step]
}

export function textBrowserPage(
  items: readonly TextBrowserItem[],
  requestedPage: number
): {
  readonly page: number
  readonly pageCount: number
  readonly items: readonly TextBrowserItem[]
} {
  const pageCount = Math.max(1, Math.ceil(items.length / TEXT_BROWSER_PAGE_SIZE))
  const page = Math.max(0, Math.min(Math.floor(requestedPage), pageCount - 1))
  return {
    page,
    pageCount,
    items: items.slice(page * TEXT_BROWSER_PAGE_SIZE, (page + 1) * TEXT_BROWSER_PAGE_SIZE)
  }
}

export function selectedTextPage(items: readonly TextBrowserItem[], id: string): number {
  return Math.max(0, Math.floor(items.findIndex((item) => item.id === id) / TEXT_BROWSER_PAGE_SIZE))
}
