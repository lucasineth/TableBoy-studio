import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react'
import { STRING_SCANNER_ENCODINGS } from '../../../../core/search/StringScannerTypes.ts'
import type { RomSearchState } from '../rom-search/romSearchTypes.ts'
import { CandidateFilterControls } from '../rom-search/CandidateFilterControls.tsx'
import { CandidateDetails } from '../rom-search/CandidateResults.tsx'
import { formatHexBytes, formatHexOffset } from '../rom-search/formatting.ts'
import {
  adaptTextResults,
  adjacentTextResult,
  DEFAULT_TEXT_BROWSER_FILTERS,
  filterTextResults,
  selectedTextPage,
  textBrowserPage,
  visibleSelection,
  type TextBrowserFilters,
  type TextBrowserItem
} from './textBrowserModel.ts'

interface Props {
  state: RomSearchState
  onCancel: () => void
}

export function TextBrowserPanel({ state, onCancel }: Props): React.JSX.Element {
  const items = useMemo(
    () => adaptTextResults(state.document!.id, state.runId, state.results),
    [state.document, state.runId, state.results]
  )
  const [filters, setFilters] = useState<TextBrowserFilters>(DEFAULT_TEXT_BROWSER_FILTERS)
  const view = useMemo(() => filterTextResults(items, filters), [items, filters])
  const [selectedId, setSelectedId] = useState<string | null>(
    () => items.find((item) => item.result.offset === state.selectedResultOffset)?.id ?? null
  )
  const [page, setPage] = useState(0)
  const selection = visibleSelection(view, selectedId)
  const selected = view.find((item) => item.id === selection)
  const viewport = textBrowserPage(view, page)
  const listRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const row = listRef.current?.querySelector<HTMLElement>('[aria-selected="true"]')
    if (row && row.getClientRects().length > 0) row.scrollIntoView({ block: 'nearest' })
  }, [selection, viewport.page])
  const select = (item: TextBrowserItem): void => {
    setSelectedId(item.id)
    setPage(selectedTextPage(view, item.id))
  }
  const changeFilters = (next: TextBrowserFilters): void => {
    const nextView = filterTextResults(items, next)
    const nextSelection = visibleSelection(nextView, selectedId)
    setSelectedId(nextSelection)
    setFilters(next)
    setPage(nextSelection ? selectedTextPage(nextView, nextSelection) : 0)
  }
  const move = (step: -1 | 1): void => {
    const next = adjacentTextResult(view, selection, step)
    if (next) select(next)
  }
  const navigate = (event: KeyboardEvent<HTMLDivElement>): void => {
    if (!['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return
    event.preventDefault()
    // Keep focus on the persistent list when navigation replaces the current page.
    event.currentTarget.focus()
    if (event.key === 'Home' && view[0]) select(view[0])
    else if (event.key === 'End' && view.at(-1)) select(view.at(-1)!)
    else move(event.key === 'ArrowUp' ? -1 : 1)
  }

  return (
    <div className="text-browser">
      <div className="text-browser-controls">
        <span>String Scanner candidates · Standard encoding · No .tbl decoding</span>
        <button
          type="button"
          className="secondary-button"
          disabled={state.status !== 'searching'}
          onClick={onCancel}
        >
          Cancel search
        </button>
      </div>
      <div className="text-browser-controls">
        <label>
          Search available previews
          <input
            type="search"
            value={filters.previewQuery}
            onChange={(event) => changeFilters({ ...filters, previewQuery: event.target.value })}
          />
        </label>
        <label>
          Encoding
          <select
            value={filters.encoding}
            onChange={(event) =>
              changeFilters({
                ...filters,
                encoding: event.target.value as TextBrowserFilters['encoding']
              })
            }
          >
            <option value="any">Any encoding</option>
            {STRING_SCANNER_ENCODINGS.map((encoding) => (
              <option key={encoding} value={encoding}>
                {encoding}
              </option>
            ))}
          </select>
        </label>
        <label>
          Sort by
          <select
            value={filters.sort}
            onChange={(event) =>
              changeFilters({ ...filters, sort: event.target.value as TextBrowserFilters['sort'] })
            }
          >
            <option value="offset">Offset</option>
            <option value="length">Byte length</option>
            <option value="confidence">Confidence</option>
          </select>
        </label>
        <label>
          Order
          <select
            value={filters.direction}
            onChange={(event) =>
              changeFilters({
                ...filters,
                direction: event.target.value as TextBrowserFilters['direction']
              })
            }
          >
            <option value="ascending">Ascending</option>
            <option value="descending">Descending</option>
          </select>
        </label>
        <button
          type="button"
          className="secondary-button"
          onClick={() => changeFilters(DEFAULT_TEXT_BROWSER_FILTERS)}
        >
          Reset browser filters
        </button>
      </div>
      <CandidateFilterControls
        filters={filters.candidate}
        onChange={(candidate) => changeFilters({ ...filters, candidate })}
        visibleCount={view.length}
        totalCount={items.length}
      />
      <div className="text-browser-body">
        <div className="text-browser-list-panel">
          <div
            ref={listRef}
            className="text-browser-list"
            role="listbox"
            aria-label="Text candidates"
            tabIndex={0}
            onKeyDown={navigate}
            aria-activedescendant={
              viewport.items.some((item) => item.id === selection)
                ? `text-${encodeURIComponent(selection!)}`
                : undefined
            }
          >
            {viewport.items.map((item) => (
              <button
                type="button"
                tabIndex={-1}
                role="option"
                id={`text-${encodeURIComponent(item.id)}`}
                aria-selected={item.id === selection}
                key={item.id}
                className={`rom-search-result${item.id === selection ? ' rom-search-result--selected' : ''}`}
                onClick={() => select(item)}
              >
                <span className="rom-search-result__offset">
                  {formatHexOffset(item.result.offset, state.document!.size)}
                </span>
                <span className="rom-search-result__primary">
                  {item.result.text}
                  {item.result.previewTruncated ? '…' : ''}
                </span>
                <span className="rom-search-result__context">
                  {item.result.encoding} · {item.result.length} bytes ·{' '}
                  {item.result.analysis?.confidence ?? 'Unavailable'} confidence
                  {item.result.previewTruncated ? ' · Partial preview' : ''}
                </span>
              </button>
            ))}
            {view.length === 0 ? (
              <p className="text-browser-empty" role="status">
                {items.length > 0
                  ? 'No candidates match the filters. Reset filters to restore originals.'
                  : state.status === 'searching'
                    ? 'Waiting for String Scanner batches. Other search modes do not populate this browser.'
                    : state.status === 'error'
                      ? 'The search failed. Available partial candidates remain inspectable.'
                      : 'No String Scanner candidates available. Configure and run a scan explicitly in Text Search.'}
              </p>
            ) : null}
          </div>
          <div className="rom-search-pagination">
            <button
              type="button"
              disabled={viewport.page === 0}
              onClick={() => setPage(viewport.page - 1)}
            >
              Previous page
            </button>
            <span>
              Page {viewport.page + 1} of {viewport.pageCount} · {view.length} candidates
            </span>
            <button
              type="button"
              disabled={viewport.page === viewport.pageCount - 1}
              onClick={() => setPage(viewport.page + 1)}
            >
              Next page
            </button>
          </div>
        </div>
        <aside className="text-browser-inspector" aria-label="Text inspector">
          <div className="text-browser-controls">
            <button
              type="button"
              className="secondary-button"
              disabled={!adjacentTextResult(view, selection, -1)}
              onClick={() => move(-1)}
            >
              Previous text
            </button>
            <button
              type="button"
              className="secondary-button"
              disabled={!adjacentTextResult(view, selection, 1)}
              onClick={() => move(1)}
            >
              Next text
            </button>
          </div>
          {selected ? (
            <>
              <h2>{formatHexOffset(selected.result.offset, state.document!.size)}</h2>
              <p>String Scanner · Decoder: {selected.result.encoding}</p>
              <p>
                {selected.result.length} bytes · {selected.result.characterLength} characters
              </p>
              <p>
                {selected.result.previewTruncated
                  ? 'Partial text preview — complete string is not available here.'
                  : 'Complete decoded candidate text.'}
              </p>
              <pre className="text-browser-preview">{selected.result.text}</pre>
              <p className="rom-search-result__bytes">
                Preview bytes: {formatHexBytes(selected.result.matchedBytes)}
              </p>
              {selected.result.analysis ? (
                <>
                  <p>
                    Possible delimiter/boundary:{' '}
                    {selected.result.analysis.possibleBoundary ?? 'None identified'} (not proof of a
                    terminator).
                  </p>
                  <CandidateDetails analysis={selected.result.analysis} />
                </>
              ) : (
                <p>Analysis unavailable; no confidence has been inferred.</p>
              )}
            </>
          ) : (
            <p>Select a candidate to inspect its text and existing evidence.</p>
          )}
        </aside>
      </div>
    </div>
  )
}
