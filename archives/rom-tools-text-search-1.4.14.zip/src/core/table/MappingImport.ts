import { writeUint16, type ByteOrder } from '../bytes/Endianness.ts'
import type { RelativeCharacterMapping } from '../search/RelativeSearchTypes.ts'
import { cloneTableEntries, type TableDocument } from './TableDocument.ts'
import { TableValidator } from './TableValidator.ts'

export type MappingSource =
  | { readonly valueWidth: 1; readonly byteOrder?: never }
  | { readonly valueWidth: 2; readonly byteOrder: ByteOrder }

export interface MappingCandidate {
  readonly key: readonly number[]
  readonly value: string
}

export interface ReviewedMapping extends MappingCandidate {
  readonly approved: boolean
  readonly overwrite: boolean
}

export type MappingStatus = 'candidate' | 'confirmed' | 'conflict'

export interface MappingReviewRow {
  readonly status: MappingStatus
  readonly existingValue?: string
  readonly error?: string
}

export class MappingImportError extends Error {
  readonly code:
    'INVALID_MAPPING' | 'INCOMPATIBLE_MODE' | 'NO_APPROVED_MAPPINGS' | 'MAPPING_CONFLICT'
  constructor(
    code: 'INVALID_MAPPING' | 'INCOMPATIBLE_MODE' | 'NO_APPROVED_MAPPINGS' | 'MAPPING_CONFLICT',
    message: string
  ) {
    super(message)
    this.code = code
    this.name = 'MappingImportError'
  }
}

/** Convert only reported mappings, preserving the physical byte order of the match. */
export function extractMappingCandidates(
  mappings: readonly RelativeCharacterMapping[],
  source: MappingSource
): MappingCandidate[] {
  if (
    (source.valueWidth !== 1 && source.valueWidth !== 2) ||
    (source.valueWidth === 1 && source.byteOrder !== undefined) ||
    (source.valueWidth === 2 &&
      source.byteOrder !== 'little-endian' &&
      source.byteOrder !== 'big-endian')
  ) {
    throw new MappingImportError('INVALID_MAPPING', 'Invalid mapping width or byte order.')
  }
  const byCharacter = new Map<string, number>()
  const byValue = new Map<number, string>()
  const candidates: MappingCandidate[] = []
  for (const mapping of mappings) {
    const maximum = source.valueWidth === 1 ? 0xff : 0xffff
    if (
      !Number.isInteger(mapping.value) ||
      mapping.value < 0 ||
      mapping.value > maximum ||
      typeof mapping.character !== 'string' ||
      Array.from(mapping.character).length !== 1
    ) {
      throw new MappingImportError(
        'INVALID_MAPPING',
        'A candidate must map one symbol to a valid value.'
      )
    }
    if (
      (byCharacter.has(mapping.character) &&
        byCharacter.get(mapping.character) !== mapping.value) ||
      (byValue.has(mapping.value) && byValue.get(mapping.value) !== mapping.character)
    ) {
      throw new MappingImportError('INVALID_MAPPING', 'Candidate mappings must be bijective.')
    }
    if (byValue.has(mapping.value)) continue
    byCharacter.set(mapping.character, mapping.value)
    byValue.set(mapping.value, mapping.character)
    candidates.push({
      key:
        source.valueWidth === 1
          ? [mapping.value]
          : Array.from(writeUint16(mapping.value, source.byteOrder)),
      value: mapping.character
    })
  }
  return candidates
}

/** Review against the current document; this function never changes either input. */
export function reviewMappingImport(
  document: TableDocument,
  rows: readonly ReviewedMapping[],
  source: MappingSource
): MappingReviewRow[] {
  extractMappingCandidates([], source)
  const validator = new TableValidator()
  const documentValid =
    validator.validate(document.entries).valid &&
    document.entries.every((entry) => entry.key.length === source.valueWidth)
  const expectedMode = source.valueWidth === 1 ? '8-bit' : '16-bit'
  const currentByKey = new Map(document.entries.map((entry) => [keyId(entry.key), entry]))
  const approved = rows.filter((row) => row.approved)
  const selectedKeyCounts = new Map<string, number>()
  const selectedValueCounts = new Map<string, number>()
  for (const row of approved) {
    const key = keyId(row.key)
    selectedKeyCounts.set(key, (selectedKeyCounts.get(key) ?? 0) + 1)
    selectedValueCounts.set(row.value, (selectedValueCounts.get(row.value) ?? 0) + 1)
  }
  // Evaluate the final representation: explicitly replaced old values do not cause false conflicts.
  const replacedKeys = new Set(approved.map((row) => keyId(row.key)))
  const remainingValues = new Set(
    document.entries
      .filter((entry) => !replacedKeys.has(keyId(entry.key)))
      .map((entry) => entry.value)
  )

  return rows.map((row) => {
    const existing = currentByKey.get(keyId(row.key))
    const conflictsWithKey = existing !== undefined && existing.value !== row.value
    let error: string | undefined
    if (document.mode !== expectedMode)
      error = 'The current table has a different key width. Create a new table instead.'
    else if (!documentValid) error = 'Resolve existing table validation errors before importing.'
    else if (
      row.key.length !== source.valueWidth ||
      validator.validateEntry({ key: [...row.key], value: row.value }).length > 0
    ) {
      error = 'The association must have a valid key and a non-empty value.'
    }
    if (row.approved) {
      const duplicateKey = selectedKeyCounts.get(keyId(row.key))! > 1
      const duplicateValue = selectedValueCounts.get(row.value)! > 1
      if (duplicateKey) error = 'Duplicate key in the approved selection.'
      else if (duplicateValue || remainingValues.has(row.value))
        error = 'This text is already mapped to a different key; encoding would be ambiguous.'
      else if (conflictsWithKey && !row.overwrite)
        error = 'Approve replacement of the existing entry explicitly.'
    }
    return {
      status: error || conflictsWithKey ? 'conflict' : row.approved ? 'confirmed' : 'candidate',
      existingValue: existing?.value,
      error
    }
  })
}

export interface MappingImportPlan {
  readonly document: TableDocument
  readonly added: number
  readonly replaced: number
  readonly unchanged: number
}

/** Prepare the entire transaction, or throw before returning any changed document. */
export function prepareMappingImport(
  document: TableDocument,
  rows: readonly ReviewedMapping[],
  source: MappingSource
): MappingImportPlan {
  const selected = rows.filter((row) => row.approved)
  if (selected.length === 0)
    throw new MappingImportError('NO_APPROVED_MAPPINGS', 'Approve at least one association.')
  const review = reviewMappingImport(document, rows, source)
  const invalid = review.find((row, index) => rows[index].approved && row.error)
  if (invalid)
    throw new MappingImportError(
      document.mode !== (source.valueWidth === 1 ? '8-bit' : '16-bit')
        ? 'INCOMPATIBLE_MODE'
        : 'MAPPING_CONFLICT',
      invalid.error!
    )
  const entries = cloneTableEntries(document.entries)
  const indexByKey = new Map(entries.map((entry, index) => [keyId(entry.key), index]))
  let added = 0
  let replaced = 0
  let unchanged = 0
  for (const row of selected) {
    const index = indexByKey.get(keyId(row.key))
    if (index === undefined) {
      entries.push({ key: [...row.key], value: row.value })
      added += 1
    } else if (entries[index].value === row.value) unchanged += 1
    else {
      entries[index] = { ...entries[index], value: row.value }
      replaced += 1
    }
  }
  return { document: { mode: document.mode, entries }, added, replaced, unchanged }
}

function keyId(key: readonly number[]): string {
  return key.join(',')
}
