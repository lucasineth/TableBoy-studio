import { TableDecoder, TableEncoder, TableCodecError } from '../codec/index.ts'
import { CharacterEncodingError, getCharacterEncoding } from '../encoding/index.ts'
import { BinarySearchEngine } from './BinarySearchEngine.ts'
import { RelativeSearchEngine } from './RelativeSearchEngine.ts'
import type { RelativeCharacterMapping } from './RelativeSearchTypes.ts'
import { TableSearchEngine } from './TableSearchEngine.ts'
import { SearchError } from './SearchError.ts'
import type { SearchOptions, SearchResult } from './SearchTypes.ts'
import {
  KNOWN_TEXT_LIMITS,
  type KnownTextMethod,
  type KnownTextSearchOptions,
  type KnownTextSearchResult
} from './KnownTextTypes.ts'

export class KnownTextSearchError extends Error {
  readonly code: 'INVALID_KNOWN_QUERIES' | 'INVALID_CONTEXT_BYTES'
  constructor(code: KnownTextSearchError['code'], message: string) {
    super(message)
    this.name = 'KnownTextSearchError'
    this.code = code
  }
}

const asciiEntries = Array.from({ length: 128 }, (_, value) => ({
  key: [value],
  value: String.fromCodePoint(value)
}))

/** Composition only: all matching remains in the established engines. */
export class KnownTextSearch {
  search(
    input: Uint8Array,
    queries: readonly string[],
    method: KnownTextMethod,
    options: KnownTextSearchOptions = {}
  ): KnownTextSearchResult[] {
    if (
      !Array.isArray(queries) ||
      queries.length === 0 ||
      queries.some((query) => typeof query !== 'string' || query.length === 0)
    )
      throw new KnownTextSearchError(
        'INVALID_KNOWN_QUERIES',
        'Supply at least one non-empty known text query.'
      )
    const contextBytes = options.contextBytes ?? 0
    if (
      !Number.isSafeInteger(contextBytes) ||
      contextBytes < 0 ||
      contextBytes > KNOWN_TEXT_LIMITS.contextBytes
    )
      throw new KnownTextSearchError(
        'INVALID_CONTEXT_BYTES',
        `Context must be between 0 and ${KNOWN_TEXT_LIMITS.contextBytes} bytes per side.`
      )
    const results: KnownTextSearchResult[] = []
    const maxResults = options.maxResults ?? KNOWN_TEXT_LIMITS.maxResults
    const rangeSize = (options.endOffset ?? input.length) - (options.startOffset ?? 0)
    const cancellation = (): void => {
      if (options.signal?.aborted)
        throw new SearchError('SEARCH_ABORTED', 'The search was aborted.')
    }
    const encoder =
      method.kind === 'encoding' && method.encoding !== 'ascii'
        ? getCharacterEncoding(method.encoding)
        : undefined
    const encode = (query: string): Uint8Array => {
      if (encoder) return encoder.encode(query)
      try {
        return new TableEncoder().encode(query, asciiEntries)
      } catch (error) {
        if (!(error instanceof TableCodecError)) throw error
        throw new CharacterEncodingError(
          'UNREPRESENTABLE_CHARACTER',
          'ASCII cannot represent part of this query.',
          {
            encodingId: 'ascii',
            position: error.position,
            fragment: error.fragment
          }
        )
      }
    }
    const decode = (bytes: Uint8Array): string =>
      method.kind === 'table'
        ? new TableDecoder().decode(bytes, method.entries)
        : encoder
          ? encoder.decode(bytes)
          : new TableDecoder().decode(bytes, asciiEntries)

    for (let queryIndex = 0; queryIndex < queries.length; queryIndex++) {
      cancellation()
      const query = queries[queryIndex]
      const enrich = (
        match: SearchResult & { mappings?: readonly RelativeCharacterMapping[] }
      ): KnownTextSearchResult => {
        cancellation()
        const end = match.offset + match.length
        const before = contextBytes
          ? input.slice(
              Math.max(options.startOffset ?? 0, match.offset - contextBytes),
              match.offset
            )
          : undefined
        const after = contextBytes
          ? input.slice(end, Math.min(options.endOffset ?? input.length, end + contextBytes))
          : undefined
        let decodedText: string | undefined
        let decodeError: string | undefined
        if (before && after && method.kind !== 'relative') {
          try {
            decodedText = decode(input.subarray(match.offset - before.length, end + after.length))
          } catch (error) {
            if (!(error instanceof TableCodecError || error instanceof CharacterEncodingError))
              throw error
            decodeError = error.code
          }
        }
        return {
          offset: match.offset,
          length: match.length,
          query,
          queryIndex,
          method: method.kind,
          decoder:
            method.kind === 'encoding'
              ? method.encoding
              : method.kind === 'table'
                ? method.label
                : `Relative ${method.options.valueWidth === 2 ? `16-bit ${method.options.byteOrder}` : '8-bit'}`,
          matchedBytes: input.slice(
            match.offset,
            Math.min(end, match.offset + KNOWN_TEXT_LIMITS.previewBytes)
          ),
          matchedBytesTruncated: match.length > KNOWN_TEXT_LIMITS.previewBytes,
          mappings: match.mappings ?? [],
          mappingSource:
            method.kind === 'relative'
              ? method.options.valueWidth === 2
                ? { valueWidth: 2, byteOrder: method.options.byteOrder }
                : { valueWidth: 1 }
              : undefined,
          context: before && after ? { before, after, decodedText, decodeError } : undefined
        }
      }
      const callbacks: SearchOptions = {
        startOffset: options.startOffset,
        endOffset: options.endOffset,
        alignment: options.alignment,
        maxResults: maxResults - results.length,
        signal: options.signal,
        onProgress: (progress) =>
          options.onProgress?.({
            processed: queryIndex * rangeSize + Math.floor((rangeSize * progress.percentage) / 100),
            total: rangeSize * queries.length,
            percentage: (queryIndex * 100 + progress.percentage) / queries.length
          })
      }
      const onResults = (
        batch: readonly (SearchResult & { mappings?: readonly RelativeCharacterMapping[] })[]
      ): void => {
        const enriched = batch.map(enrich)
        results.push(...enriched)
        options.onResults?.(enriched)
      }
      if (method.kind === 'encoding')
        new BinarySearchEngine().search(input, encode(query), { ...callbacks, onResults })
      else if (method.kind === 'table')
        new TableSearchEngine().search(input, query, method.entries, {
          ...callbacks,
          onResults,
          contextBytes: 0
        })
      else
        new RelativeSearchEngine().search(input, query, {
          ...method.options,
          ...callbacks,
          onResults
        })
      if (results.length >= maxResults) break
    }
    return results
  }
}
