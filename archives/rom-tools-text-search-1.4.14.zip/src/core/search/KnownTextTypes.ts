import type { TableEntry } from '../table/TableEntry.ts'
import type { MappingSource } from '../table/MappingImport.ts'
import type { RelativeSearchOptions, RelativeCharacterMapping } from './RelativeSearchTypes.ts'
import type { SearchOptions, SearchResult } from './SearchTypes.ts'
import type { StringScannerEncoding } from './StringScannerTypes.ts'

export const KNOWN_TEXT_LIMITS = Object.freeze({
  queries: 16,
  queryLength: 512,
  totalQueryLength: 4096,
  contextBytes: 128,
  maxResults: 1000,
  previewBytes: 1024
})
export type KnownTextMethod =
  | { readonly kind: 'encoding'; readonly encoding: StringScannerEncoding }
  | { readonly kind: 'table'; readonly entries: readonly TableEntry[]; readonly label: string }
  | {
      readonly kind: 'relative'
      readonly options: Omit<RelativeSearchOptions, keyof SearchOptions> & MappingSource
    }

export interface KnownTextSearchResult extends SearchResult {
  readonly query: string
  readonly queryIndex: number
  readonly method: 'encoding' | 'table' | 'relative'
  readonly decoder: string
  readonly matchedBytes: Uint8Array
  readonly matchedBytesTruncated: boolean
  readonly mappings: readonly RelativeCharacterMapping[]
  readonly mappingSource?: MappingSource
  readonly context?: {
    readonly before: Uint8Array
    readonly after: Uint8Array
    readonly decodedText?: string
    readonly decodeError?: string
  }
}

export interface KnownTextSearchOptions extends Omit<SearchOptions, 'onResults'> {
  readonly contextBytes?: number
  readonly onResults?: (batch: readonly KnownTextSearchResult[]) => void
}
