import { SearchError } from './SearchError.ts'
import type { SearchCancellation } from './SearchTypes.ts'
import { STRING_PREVIEW_CHARACTERS, type StringScannerResult } from './StringScannerTypes.ts'

export type CandidateConfidence = 'low' | 'medium' | 'high'
export type CandidateBoundary = 'nul' | 'line-break' | 'document-end' | 'range-end'

export interface TextCandidateAnalysis {
  readonly confidence: CandidateConfidence
  readonly evidence: readonly string[]
  readonly scope: 'complete' | 'preview'
  readonly characterLength: number
  readonly analyzedCharacters: number
  readonly printableRatio: number
  readonly controlCharacters: number
  readonly diversity: number
  readonly letterRatio: number
  readonly numberRatio: number
  readonly punctuationRatio: number
  readonly symbolRatio: number
  readonly spaceRatio: number
  readonly longestRepeatedRun: number
  readonly highlyRepetitive: boolean
  readonly knownTokenCount: number
  readonly decodingErrorCount: number
  readonly possibleBoundary?: CandidateBoundary
}

export interface TextCandidateInput {
  readonly text: string
  readonly encoding: string
  readonly characterLength?: number
  readonly previewTruncated?: boolean
  /** Explicit decoder metadata only: bracketed text is not assumed to be a token. */
  readonly knownTokens?: readonly string[]
  readonly decodingErrors?: readonly string[]
  readonly possibleBoundary?: CandidateBoundary
}

const SAMPLE_LIMIT = STRING_PREVIEW_CHARACTERS
const LETTER = /[\p{L}\p{M}]/u
const NUMBER = /\p{N}/u
const PUNCTUATION = /\p{P}/u
const SYMBOL = /\p{S}/u
const SPACE = /\p{Zs}/u
const CONTROL = /\p{C}/u

/** Bounded, deterministic evidence; confidence is not a calibrated probability. */
export function analyzeTextCandidate(input: TextCandidateInput): TextCandidateAnalysis {
  const sample: string[] = []
  let sampledText = ''
  for (const character of input.text) {
    if (sample.length === SAMPLE_LIMIT) break
    sample.push(character)
    sampledText += character
  }
  const tokens = [...new Set(input.knownTokens ?? [])]
    .filter((token) => token.length > 0)
    .sort((a, b) => b.length - a.length)
  const characters: string[] = []
  let knownTokenCount = 0
  for (let index = 0; index < sampledText.length;) {
    const token = tokens.find((value) => sampledText.startsWith(value, index))
    if (token) {
      knownTokenCount++
      index += token.length
    } else {
      const character = String.fromCodePoint(sampledText.codePointAt(index)!)
      characters.push(character)
      index += character.length
    }
  }

  let controls = 0
  let letters = 0
  let numbers = 0
  let punctuation = 0
  let symbols = 0
  let spaces = 0
  let run = 0
  let longestRepeatedRun = 0
  const frequency = new Map<string, number>()
  characters.forEach((character, index) => {
    controls += Number(CONTROL.test(character))
    letters += Number(LETTER.test(character))
    numbers += Number(NUMBER.test(character))
    punctuation += Number(PUNCTUATION.test(character))
    symbols += Number(SYMBOL.test(character))
    spaces += Number(SPACE.test(character))
    frequency.set(character, (frequency.get(character) ?? 0) + 1)
    run = index > 0 && character === characters[index - 1] ? run + 1 : 1
    longestRepeatedRun = Math.max(longestRepeatedRun, run)
  })
  const count = characters.length
  const ratio = (value: number): number => (count === 0 ? 0 : value / count)
  const diversity = ratio(frequency.size)
  const dominantRatio = ratio(Math.max(0, ...frequency.values()))
  // Small-period runs detect ABAB... without ROM-sized transforms or regex matching.
  let periodicRun = 0
  for (let period = 1; period <= 8 && period * 2 <= count; period++) {
    let matching = 0
    for (let index = period; index < count; index++) {
      matching = characters[index] === characters[index - period] ? matching + 1 : 0
      if (matching >= period) periodicRun = Math.max(periodicRun, matching + period)
    }
  }
  const highlyRepetitive =
    count >= 4 &&
    (dominantRatio >= 0.75 ||
      longestRepeatedRun >= Math.max(4, count * 0.5) ||
      (periodicRun >= 8 && periodicRun / count >= 0.6))
  const decodingErrorCount = input.decodingErrors?.length ?? 0
  let characterLength = input.characterLength
  if (characterLength === undefined) {
    characterLength = 0
    const iterator = input.text[Symbol.iterator]()
    while (!iterator.next().done) characterLength++
  }
  const scope = input.previewTruncated || characterLength > sample.length ? 'preview' : 'complete'
  const evidence: string[] = []
  evidence.push(
    controls === 0
      ? 'No control characters in analyzed text.'
      : `${controls} control characters in analyzed text.`
  )
  evidence.push(
    highlyRepetitive
      ? 'High repetition or a short periodic pattern.'
      : 'No strong repetitive pattern detected.'
  )
  evidence.push(
    diversity >= 0.3 ? 'Varied character distribution.' : 'Limited character diversity.'
  )
  if (ratio(letters) >= 0.45)
    evidence.push('Letters or combining marks dominate the analyzed text.')
  else evidence.push('Few letters; numeric, symbolic or binary-looking content remains possible.')
  if (input.encoding === 'shift-jis')
    evidence.push('Unicode letter categories include Japanese scripts; spaces are not required.')
  if ((input.encoding === 'cp437' || input.encoding === 'cp850') && ratio(symbols) > 0.3)
    evidence.push('OEM graphic symbols occupy a large part of the text.')
  if (knownTokenCount > 0)
    evidence.push(
      `${knownTokenCount} explicitly known decoder tokens excluded from character-distribution rules.`
    )
  if (decodingErrorCount > 0) evidence.push(`${decodingErrorCount} reported decoding errors.`)
  if (characterLength < 8)
    evidence.push('Short candidate: legitimate menu labels can still receive low confidence.')
  if (input.possibleBoundary)
    evidence.push(
      `Possible boundary: ${input.possibleBoundary}; this does not prove a text terminator.`
    )
  if (scope === 'preview')
    evidence.push('Analysis covers the bounded preview, not the complete string.')

  const printableRatio = ratio(count - controls)
  // OEM pages contain graphic glyphs; Shift-JIS permits a wider symbol mix.
  // Neither Japanese nor Latin text is required to contain spaces.
  const oem = input.encoding === 'cp437' || input.encoding === 'cp850'
  const highSymbolLimit = oem ? 0.15 : input.encoding === 'shift-jis' ? 0.4 : 0.3
  let confidence: CandidateConfidence = 'medium'
  if (
    characterLength < 8 ||
    highlyRepetitive ||
    controls > 0 ||
    decodingErrorCount > 0 ||
    count === 0 ||
    ratio(letters) < 0.2
  )
    confidence = 'low'
  else if (
    printableRatio === 1 &&
    ratio(letters) >= 0.45 &&
    diversity >= 0.3 &&
    ratio(symbols) <= highSymbolLimit
  )
    confidence = 'high'
  if (ratio(symbols) > highSymbolLimit)
    evidence.push(
      'Symbol proportion exceeds the high-confidence threshold for this encoding profile.'
    )

  return {
    confidence,
    evidence,
    scope,
    characterLength,
    analyzedCharacters: sample.length,
    printableRatio,
    controlCharacters: controls,
    diversity,
    letterRatio: ratio(letters),
    numberRatio: ratio(numbers),
    punctuationRatio: ratio(punctuation),
    symbolRatio: ratio(symbols),
    spaceRatio: ratio(spaces),
    longestRepeatedRun,
    highlyRepetitive,
    knownTokenCount,
    decodingErrorCount,
    possibleBoundary: input.possibleBoundary
  }
}

/** Enrich an existing scanner batch. Does not scan, decode or copy document bytes. */
export function analyzeStringBatch(
  results: readonly StringScannerResult[],
  options: {
    readonly signal?: SearchCancellation
    readonly boundaryAt?: (result: StringScannerResult) => CandidateBoundary | undefined
  } = {}
): StringScannerResult[] {
  return results.map((result) => {
    if (options.signal?.aborted) throw new SearchError('SEARCH_ABORTED', 'The search was aborted.')
    return {
      ...result,
      analysis: analyzeTextCandidate({ ...result, possibleBoundary: options.boundaryAt?.(result) })
    }
  })
}

export interface CandidateFilters {
  readonly minimumConfidence: 'any' | CandidateConfidence
  readonly minimumLength: number
  readonly lettersOnly: boolean
  readonly hideRepetitive: boolean
  readonly hideDecodingErrors: boolean
}

export const DEFAULT_CANDIDATE_FILTERS: CandidateFilters = Object.freeze({
  minimumConfidence: 'any',
  minimumLength: 0,
  lettersOnly: false,
  hideRepetitive: false,
  hideDecodingErrors: false
})

/** View predicate only; never alters the original result or its analysis. */
export function matchesCandidateFilters(
  result: StringScannerResult,
  filters: CandidateFilters
): boolean {
  if (result.characterLength < filters.minimumLength) return false
  const analysis = result.analysis
  if (!analysis)
    return (
      filters.minimumConfidence === 'any' &&
      !filters.lettersOnly &&
      !filters.hideRepetitive &&
      !filters.hideDecodingErrors
    )
  const ranks = { low: 0, medium: 1, high: 2 }
  return (
    (filters.minimumConfidence === 'any' ||
      ranks[analysis.confidence] >= ranks[filters.minimumConfidence]) &&
    (!filters.lettersOnly || analysis.letterRatio > 0) &&
    (!filters.hideRepetitive || !analysis.highlyRepetitive) &&
    (!filters.hideDecodingErrors || analysis.decodingErrorCount === 0)
  )
}
